# Changelog: @xayaarcade/sdk

Consumers vendor this package as a tarball, so a version bump arrives when you
run your repo's `vendor-sdk` script, not silently. Read this file FIRST on
every bump: breaking changes are marked **BREAKING** and say who they break.
Where a repo tag `sdk-vX.Y.Z` exists it names that release's exact commit, but
the tag series is not complete: do not read a missing tag as a missing
release. The authoritative pin for what a game repo is actually carrying is the
`vendor/PLATFORM-COMMIT` its `vendor-sdk.sh` wrote beside the tarball: the
platform commit the vendored bytes were packed from, refused unless that
checkout was clean. Each game repo's `scripts/sdk-freshness.sh` compares its
vendored version against a platform checkout first (`$ARCADE_PLATFORM`, then
the sibling `../arcade-platform`) and falls back to the highest `sdk-v*` tag on
the remote only when neither is reachable, so on a tag-only comparison a
newer untagged release reads as "current" when it is not.

## 0.20.5

- A peer proof is refused when any of its states carries more signature
  entries than the channel has seats, or an entry longer than 65 bytes. Such
  padding credits no one but rode into every proof built on it, up to a close
  too large to send.
- A proof taken from chain is held without that padding (`withoutPadding`), so
  the client's extensions, disputes and closes never carry it.
- After the bootstrap, an on-chain update that changes the channel's metadata,
  reinit state, proof or dispute height, or reports it gone, is applied only
  once a direct `getchannel` read agrees; one that only moves the block is
  applied at once. A read that fails, rather than disagrees, still lets through
  a new or moved dispute on the state already held, so an outage of the read
  cannot run out the window to answer it. The bootstrap also compares the
  dispute height, and `updateOnChain` takes `null` for a channel that has gone.
- Peer proofs are verified one at a time: of those that arrive meanwhile only
  the one with the highest turn count waits, the rest resolve `false`, and so
  does the waiting one when a reinit lands first.
- A standalone join refuses a match whose on-chain game type is not the page's.
- A lobby seating a name with a character outside 0x20..0x7E, which no move can
  carry, is not offered as joinable and a join into it is refused; your own
  such lobby stays listed so you can leave it.
- A paid create or join under such a name is refused before any wallet prompt
  (`UNUSABLE_NAME_COPY`, also the copy for the contract's "invalid player
  name"). `isMoveSafeName` is exported.
- Wager contract version 3 is accepted alongside 2, still matched exactly, and
  its new refusals have player copy.
- A create while wagering is off says "Wagering is not available right now.",
  like every other wager write.
- `loadWallet` (e2e) names the errno code when the keyfile cannot be read.
- `contentBuildId` on `@xayaarcade/sdk/server`: a Next build id hashed from the
  build's inputs, so the same source exports the same bundle.
- 0.20.4 overstated the adopted proof's trim: it is trimmed as the client's
  own extensions are (`optimizeProof`), one transition longer than the native
  trim.

## 0.20.4

- A signature is accepted only as the referee accepts it: 65 bytes ending in
  v = 27 or 28. One accepted here but refused on chain made every proof built
  on it one the referee would refuse.
- A peer proof over the referee's 1024-transition or 1024-signature ceiling is
  refused before any work is done on it, the same rejected bytes are not
  walked twice, and an adopted proof is held (and later sent) in its shortest
  form. `optimizeProof` is exported.
- A closing resolution that stopped pending while the channel stayed where it
  was shows the existing Retry once the chain view is two blocks past it.
- A frame over the relay's 262,144-byte cap is not sent; the relay would close
  the socket on it and the rejoin would send it again.
- A channel is bootstrapped only once a direct `getchannel` read agrees with
  the relay's view of it; until then it retries each block.
- Game CSP: `'wasm-unsafe-eval'` replaces `'unsafe-eval'`, except under a
  development server, where React needs eval.
- A standalone join re-reads the match on chain and refuses a bet or seat count
  that differs from the listing. The approval button reads "Allow WCHI stakes
  (revocable)" (`APPROVE_WCHI_LABEL`), because the allowance is unlimited.
- `loadWallet` (e2e) throws a fixed message on a bad keyfile, never text taken
  from the key.

## 0.20.3

- A direct read that a push or tick overtook while it was in flight is
  dropped, even at the same height: the read started first, so it is the
  older view of the two, and height cannot tell them apart. One direct read
  runs at a time, so a slow referee no longer has reads stacked on it. The
  pushed stream itself is applied as it comes, a full state below the held
  tip included, because the ticks that follow describe that state.
- A remembered relay ranking is used only once its nearest relay answers a
  single readiness probe; one that does not answer falls through to a fresh
  probe round instead of parking the page on a relay that is down.

## 0.20.1

- Poll the GSP directly whenever the pushed feed stops, not only while the
  relay socket is closed. A relay reporting its own GSP link down, and a height
  that has not moved for thirty seconds under an open socket, both fall back
  the same way; the next pushed state or block tick hands the feed back. A
  direct read is applied only when it is no older than the state already held,
  and a feed that has gone quiet never moves the relay pick.
- Close a relay socket that has sat connecting for ten seconds, and treat it as
  any other dead socket: the backoff queues the next dial, and two of them move
  the frame to the next relay.
- Refuse a relay URL a browser could not dial. `isRelayUrl` now parses the URL
  instead of matching its scheme, so a port out of range, a fragment and
  embedded credentials are rejected wherever it is used: the runtime config's
  `relayUrls` and `relayUrl`, and a serving layer's startup check.

## 0.20.0

- Runtime config and `NEXT_PUBLIC_RELAY_URLS` may list several relays. The frame
  times a probe to each (`/relay/ping`), connects to the nearest, keeps the
  choice for the session, and moves to the next after two dead sockets. One
  relay listed behaves exactly as before. Hosts that list relays must also allow
  each relay's `https://` origin in `connect-src`, which `buildSecurityHeaders`
  now does for the env list.
- A `relayUrls` with an entry that is not `ws://` or `wss://`, or with more than
  eight entries, is ignored whole and the frame stays on `relayUrl` alone, so a
  serving layer must refuse such a list at startup rather than publish a plane's
  other relays into silence.
- New exports for that contract: `MAX_RELAY_URLS`, `isRelayUrl`, `relayOrigins`
  (a relay list's socket and probe origins, deduped) from the main entry and the
  node-safe `/server` subpath, plus `relayCandidates`, `pickRelay` and
  `currentRelay` from the main entry.

## 0.19.5

- Use plain punctuation in status messages and documentation comments.

## 0.19.4

- Retry failed capacity reads every eight seconds, even if the queue has not
  changed. Stop retrying after recovery or when the selected pool changes.

## 0.19.3

- Check the agreed stake and player count for joiners, including when the
  lobby initially selects a different pool. Keep their create controls hidden.

## 0.19.2

- Disable wager approval and creation while pooled capacity is full or unverified.
  Agreed matches wait for availability before requesting approval or a stake.
- Recheck joinable tables when their queue changes, disabling stale results.
  Explain waiting, table updates and full refunds for cancelled, unfilled tables.
- No rules, contract or queue-depth changes.

## 0.19.1

- Raise packed state output capacity to 16 KiB, matching the native judge.
  Initial states and move results one byte over the limit still reject.
- Deploy alongside the GSP with the same state limit and a fixed 500-million
  fuel budget per metered call. Existing deployments require a coordinated reset
  and replay; there is no activation-height switch for these limits.

## 0.19.0

- Shared dispute and resolution builders support bounded `z1` proof transport.
  Polygon senders check the GSP directly before sending; legacy, unavailable or
  syncing referees retain uncompressed proofs. All games use the same codec.
- Compression preserves the serialized proof and signatures byte for byte.
  Requires a GSP with a coordinated `proof_compression_height` activation.

## 0.18.15: 2026-09-10

One channel signing key per wallet, and honest payout timing. Vendor it over
any 0.18.x; the six first-party games and the shell call none of what moved.
**BREAKING** only for code that imported the signing-key helpers directly:
`getPreChannelSessionKey`, `migrateSessionKey` and `clearSessionKey` are gone,
`preChannelSigningAddress` is now `sessionSigningAddress`, and `getSessionKey`
takes the wallet address, not a channel id: a call that still passes a
channel id typechecks and yields a fresh key no seat carries, so grep for it.

- **A seat is signed with its wallet's key, checked against the seat.** The
  SDK used to copy a wallet's signing key out under the channel id when the
  channel opened, and read the copy back to sign with. That copy was shared by
  every seat of the channel opened from one browser: when two wallets in one
  browser each held a seat of the same match, the second to open it signed
  with the first's key: its moves refused by the counterparty and its relay
  join knocking the first tab off its seat, while the board's own key check
  still passed. There is now one key
  per wallet and no per-channel copy; the channel manager signs with the
  connected wallet's key and refuses to open a channel: before it signs or
  joins the relay, unless that key's address is the one the seat carries on
  chain. `sessionSigningAddress(wallet)` (renamed from
  `preChannelSigningAddress`) is the same derivation, so what the lobby seats,
  what the board checks and what the channel signs with can no longer differ.
- **The result screen says when a queued payout is really paid.** It promised
  payment when the next match at the stake and player count started. The queue
  is a FIFO: a start pays only the payout at its front, and a fresh win joins
  at the back behind every payout still waiting: the operator's seed groups
  included, so a winner queued three deep was told to expect money two starts
  early. The explainer and the beta payout notice now say a payout is paid
  when it reaches the front of the queue and another such match starts, one
  payout per start.

## 0.18.14: 2026-09-10

Not breaking: the channel store names the seat a match is played under.
Vendor it over any 0.18.x; a game that keeps a per-seat secret should read it.

- **`useChannelStore` carries `seatName`.** `xayaName` is the shell's live
  identity, and the shell re-posts it whenever it changes: a wallet account
  switch mid-match included, while a seat is bound on chain to the name that
  opened it. A game that looked its per-seat state up under the live name
  (a hidden-information secret, a fleet placement) went looking under the
  wrong name the moment the identity moved, and showed its player an empty
  or another seat's board while the channel kept playing correctly. The store
  now records the name `makeOpenChannel` was called with, from the moment the
  manager is created until the channel is left or reset, and a game keys its
  per-seat reads on that. One browser can also hold both seats of a match, so
  key such storage by the channel AND `seatName`, never the channel alone.

## 0.18.13: 2026-09-09

Not breaking: the state update that follows an adoption waits for every
queued commit. Vendor it over any 0.18.x with no code changes of your own.

- **No state update runs while a proof's evidence is still queued.** Commits
  reach the rules in adoption order, but the update that follows an adoption
  ran as soon as that adoption's own commit had landed, so two proofs adopted
  in one frame had the first's update run against the second's board over
  records holding only the first's turns: the game was asked for a move, and
  listeners told of a board, ahead of its evidence. An on-chain update that
  adopted nothing did the same when it arrived while a commit was queued. The
  update now runs only once no commit is pending; while one is, it belongs to
  the adoption whose commit lands last.

## 0.18.12: 2026-09-09

Not breaking: the saved proof is restored before anything acts on the
on-chain state, and commits reach the rules in adoption order. Vendor it over
any 0.18.x with no code changes of your own.

- **The saved proof is restored before the first state update.** Opening a
  channel adopted the on-chain state, ran its state update: asking the game
  for a move against that state and persisting it over the saved record, and
  only then offered the saved proof back, whose verification takes a moment.
  For those milliseconds the client held, and had saved, a state the record it
  was restoring from outranked; a tab closed inside them lost the saved turns
  for good. The channel hook now opens through `ChannelManager.bootstrap`,
  which adopts the on-chain state, verifies the saved proof, and runs one
  state update on whichever won: nothing is asked or persisted in between,
  and an on-chain update arriving mid-restore is left for the next block.
- **Commits reach the rules in adoption order.** A proof adopted from chain is
  walked through the rules asynchronously; a proof adopted before that walk
  had committed (pruned, newer, with fewer transitions) could commit first,
  leaving a rules object that keys records by turn holding the superseded
  proof's word for a turn both histories carry while the manager kept the
  newer one. Every commit (chain walk, peer proof, local move) now queues
  behind the one before it, so the adopted chain's last word is always the
  last to land; a proof still waiting to commit when a reinit lands is
  dropped, as one still verifying already was.
- `processOffChain` resolves to whether the proof was adopted; a verifier or
  rules adapter that throws mid-walk counts as not adopted instead of
  escaping.

## 0.18.11: 2026-09-07

No behaviour change: internal tidying of 0.18.9 and 0.18.10. The chain walk
takes the metadata the adoption already holds, the manager and the channel
hook share one byte comparison, and the trial seam's tests live in one file.
Vendor it over any 0.18.x with no code changes of your own.

## 0.18.10: 2026-09-07

Not breaking: a proof adopted straight from chain now reaches the trial seam.
Vendor it over any 0.18.x with no code changes of your own.

- **Moves adopted from chain reach `commitTrial` too.** A proof the manager
  takes from the chain (the peer answered a dispute while this client was
  away, or the bootstrap after a reload) used to be adopted without a walk, so
  a rules object keeping records of accepted moves never saw those moves and
  could not build on them later: for a hidden-information game that meant a
  peer's published lock missing from the observer's records and a disclosure
  that could not be built. The manager now walks such a proof's transitions
  through `applyMove(move, trial)`: checking nothing, the host already
  verified them, and calls `commitTrial` once, unless a reinit landed
  mid-walk; the game is asked for its next move only after that, so it builds
  against records that already hold the adopted moves. Rules without
  `commitTrial` get no walk; a proof with no transitions commits nothing.

## 0.18.9: 2026-09-06

Not breaking: the saved off-chain proof survives a reload, and a rules object
can keep records of accepted moves without being poisoned by rejected ones.
Vendor it over any 0.18.x with no code changes of your own; a game that keeps
per-move records should adopt the `trial` argument below.

- **The proof saved by an earlier session is restored again.** Opening a
  channel bootstrapped from the on-chain state and persisted that state before
  reading the saved record, so a turn-9 proof from before the reload was
  replaced by the turn-0 one it was meant to outrank, and a client that
  reloaded mid-match came back believing the on-chain state, which is exactly
  the state an opponent's stale dispute would settle on. The saved record is
  now read first, then offered back like any peer's proof once the chain has
  been processed: verified, and adopted only if newer.
- **Saved records carry the reinit the manager holds the proof for.** After a
  referee ejection the manager follows the new reinit, but the record kept
  being written under the reinit the channel was opened with, so it was refused
  on the next reload. `ChannelManager.getReinitId()` is the tag now.
- **A trial object rides every `applyMove` of a proof walk.**
  `ParsedBoardState.applyMove(move, trial?)` receives one scratch object per
  verification or extension, and the new optional `BoardRules.commitTrial(trial)`
  is called exactly once per proof the manager adopts from a peer or from its
  own local move, after the adoption, and never for a proof it rejected or
  dropped. A game that records something about every accepted move (a
  hidden-information ledger, a witness tap) stages it on the trial instead of
  writing it during `applyMove`, or a peer could write into its records by
  sending moves it has no right to send. Two things the contract states and a
  game must honour: a walk starts at the proof's own initial state, so
  consecutive commits overlap and may revise a turn already committed: key
  staged records by turn and replace, never append, and a proof adopted
  straight from chain reaches no trial at all. Games that keep no such records
  ignore both.

## 0.18.8: 2026-09-06

Not breaking: fewer and honest wallet prompts around a match's close and its
stake. Vendor it over any 0.18.x with no code changes of your own.

- **A closing resolution the player declines in the wallet is no longer asked
  for again on every block.** The winner's close (and the automatic answer to
  a dispute) used to be re-sent by the next on-chain push whenever the send
  came back empty, and a wallet refusal came back empty like any failure, so
  a player who pressed Reject saw a fresh prompt roughly every two seconds
  until they signed or left the page. The sender now reports a refusal as its
  own kind of failure (`MoveDeclinedError`, exported), the channel manager
  latches it, and only the player's own action: Retry on the end overlay, or
  Resolve Dispute: sends again. A send that failed for any other reason
  (node error, nonce, gas) keeps the silent per-block retry it always had.
- **Retry cannot stack a second close prompt on top of one already open.**
  `putStateOnChain` is single-flight: while a close is awaiting the wallet a
  second call returns null without sending, the hook publishes
  `closeSubmitInFlight`, and the overlay's Retry button is disabled and reads
  "Retrying..." until the wallet answers.
- **The approve gate compares the allowance to the stake in view, not to
  zero.** A player who capped the approval in their wallet (or held a finite
  allowance from elsewhere) was offered the stake button once the allowance
  dropped below the tier, and every create or join then reverted inside the
  token transfer with no approve ever offered again. `needsApprovalFor(funds,
  bet)` is the one predicate, applied to the selected tier on the create card
  and in the agreement auto-step, and to each row's own bet on the join
  lists; `needsApproval` on the hook state is that predicate applied to the
  stake in view. The create card's copy now says the MAX approval is not
  asked again unless it is capped in the wallet.

## 0.18.7: 2026-09-02

Not breaking: leaving a match of more than two seats actually removes the
seat now. Vendor it over any 0.18.x with no code changes of your own.

- **Leaving a three- or four-seat match now ejects the seat, instead of
  filing a dispute the leaver's own client answers.** A multi-seat leave
  stops producing moves, waits for the round to come to rest on the
  leaver's own seat, and files a timeout on that tip: one nobody can
  extend without the leaver's signature, so the window expires and the
  seat goes. The wait restarted its stillness window on every state-change
  notification, and those fire once per block for the on-chain push
  whether or not anything on the board moved: on a chain with blocks
  faster than the window (Polygon's are) the window could never finish, so
  the wait always ran out. Running out was then read as "the round never
  came to us", and the dispute (filed on a tip that *was* the leaver's
  seat) was reported as somebody else's: move production came back, the
  leaver's own client answered the leaver's own dispute a block later, and
  the seat stayed. Every press cost gas and the pot stayed locked behind a
  seat the survivors cannot time out, because a round-robin game cannot
  advance past a silent seat at all. The window is now restarted only when
  the board's turn or turn count actually moved, and whether the leave
  ejects you is read from the tip it files on rather than from how the
  wait ended. The wait keeps its one job: not filing on a tip the other
  players have already moved past.
- **An ejected seat no longer reads "Match closed" over a match that is
  still being played.** Above two seats an ejection removes one player and
  the survivors carry on, so the channel is still open and the board is
  still moving. The status line says "You're out: the match plays on".

## 0.18.6: 2026-09-02

Not breaking: a seat opened from another browser is now named as such instead
of connecting forever. Vendor it over any 0.18.x with no code changes of your
own.

- **A match you can't play from this browser says so, instead of connecting
  forever.** The key that signs for a channel seat is generated in one browser
  profile's storage and is derived from nothing, not your wallet, not your
  name, so continuing a match on a second device, after clearing site data, or
  after the browser evicted a partitioned frame's storage leaves you with a
  different key. The name still matched the seat, so the lobby offered "Your
  Active Game → Resume", the board tried to join, the relay refused every
  attempt, and the player sat on "Connecting to channel..." with a Leave button
  that could never fire, while every other game in the lobby stayed blocked,
  because a name holds one seat at a time. The board now recognises the seat
  before it attempts anything: no join, no retry storm, an amber banner naming
  what happened and what the match can still do (the opponent claims it by
  dispute, or it times out), and a still "Seat elsewhere" chip in place of the
  connecting line. The two-player close is still offered on both screens: it is
  an on-chain declare-loss signed by your wallet, not by the seat key, while
  the multi-seat leave, which can only be filed against the live off-chain tip a
  join would have given it, is disabled with its one reason wherever it appears
  rather than left inert. The lobby panel also names the seat, so "why can't I
  start another game?" is answered where it is asked.

## 0.18.5: 2026-09-02

Not breaking: copy and tap targets in the wagered lobby, plus two dead ends a
player was left standing at. Vendor it over any 0.18.x with no code changes of
your own.

- **An expired table now says the stake is still there, and the buttons say what
  they do.** A paid table that nobody joins expires after its window and the
  countdown flipped to "Expired: eligible to expire", leaving one red "Abort"
  beside it. Nothing said the stake was still escrowed, and a player who reads
  "Abort" as giving up leaves it there. The line names the amount and what became
  of it; the creator's press is "Reclaim stake" while their stake is the only one
  in the lobby and "Cancel table" once somebody else is seated, since it refunds
  them and takes their table away too. And a seat that did NOT create an expired
  lobby is finally offered a way out of it: its own Leave is refused once the
  lobby is one seat short and an abort is the creator's alone, so it sat beside a
  disabled button with the stake unreachable. It gets the expiry, which is
  permissionless and refunds every seat.
- **Losing a race for the last seat is now said out loud, once.** Two players
  pressing Join within the same second is one seat and two presses: the winner
  walked into the match and the loser's row simply vanished, with no banner, no
  toast and no console line: a money button pressed for nothing. The join is
  still waiting on the signer when the lobby leaves the open set, so no
  transaction of theirs exists to revert and carry the news; that departure is
  now the news itself, and a signer or contract that refuses the closed lobby
  outright is worded identically. Afterwards the abandoned join says nothing
  more: not the refusal it was always going to get, not "Transaction cancelled"
  when the player dismisses the prompt as the line asks them to, and no second
  wallet prompt for a seat that is not there. No money moves on any of it.
  Every other reason a row can leave the joinable list is told apart from a lost
  race first: above all a wallet that answers late (WalletConnect, a
  backgrounded phone) whose seat has already landed, which is the player's own
  join succeeding.
- **Every control in the paid lobby clears 44px under a coarse pointer.** The
  tier chips, the seat picker, Join and the creator's own exit all measured 38px
  on a phone. One rule on the shared button and segment classes lifts them;
  desktop sizes are unchanged.
- **The payout preview carries its unit on every figure**, rather than only the
  first: "(pot 2 WCHI − burn 0.1 WCHI − fee 0.1 WCHI)".
- **The losing side of a decided match is spoken to in the game's words, not the
  protocol's**: "Waiting for the winner to settle the match...", and the hatch
  that finishes it off is "Settle it now".

## 0.18.4: 2026-09-02

Not breaking: three connection behaviours, all of them things a player sat
looking at a still board for. Vendor it over any 0.18.x with no code changes of
your own.

- **A match open in a second tab is now said so, with a button, instead of the
  two tabs fighting over it.** The relay keeps one connection per address per
  channel and closes the one a re-join replaced; both socket layers treated
  that close as an outage and dialled straight back, so two tabs of one game
  evicted each other for as long as both were open: the losing one showing
  "Reconnecting…" with nothing to say a second tab existed, and, when the newer
  tab was closed, taking up to thirty seconds to come back while its opponent
  was offered a dispute four seconds in. That close is now recognised for what
  it is: neither layer re-dials it, the board says the match is open in another
  tab and offers one "Play here" button that takes the seat back at once. The
  other tab is then closed the same way and offered the same choice, so the two
  never fight and the player picks. A tab that has stood down offers no dispute
  and claims no healthy channel while it waits.
- **A join the relay refuses is re-signed and replayed once, a second later.**
  The signed join carries a whole-second timestamp and the relay accepts each
  signature once, so a reload landing in the same wall-clock second sent a join
  that was byte-identical to the one already accepted and was refused as a
  replay: costing the full ten-second join timeout (measured: 12.1s to get
  back into a match, against 1.6s normally). Any refusal now replays the join
  once after the clock ticks over. A full channel keeps its own repeating
  replay; every other refusal gets exactly one, so a signature the relay really
  will not take still fails promptly.
- **The reconnect ceiling is ten seconds, and the browser coming back online
  dials at once.** The backoff climbed to thirty seconds, which existed to
  bound the two-tab fight above; with that gone it is ten. A reconnect already
  waiting is also brought forward the moment the browser reports its network
  back, rather than sitting out a delay chosen before anyone knew how long the
  outage would last.

## 0.18.3: 2026-09-02

Not breaking: one more end of the same overlay. Vendor it over any 0.18.x with
no code changes of your own: if you are on 0.18.1 or 0.18.2, take this one.

- **A failed block-number read can no longer leave the "Match starting…"
  overlay standing over a lobby whose match is already over.** The overlay is
  let go at the block that settles the fill behind it, and where the chain read
  that fixes that block failed, the fill was armed with no block at all: held,
  by design, until the channel opened. For a fill that really is starting that
  is right. For one that was already over when the lobby heard of it there is
  no channel left to open, so nothing could take the overlay down and the
  create card and every Join row stayed unreachable until a reload, which is
  what a standalone lobby saw after a paid match if it came back up while the
  relay's document still listed the match just ended. Such a fill now re-reads
  the chain tip on each new block until it gets one, and settles against that
  instead; a tip read a few blocks late still bounds the fill correctly, and
  costs at most those few extra blocks of overlay on a match that is genuinely
  starting.

## 0.18.2: 2026-09-02

Not breaking: 0.18.1's fix, finished. Vendor it over 0.18.1 or 0.18.0 with no
code changes of your own: if you are on 0.18.1, take this one.

- **The finished match's "Match starting…" overlay comes down on a lobby the
  relay is feeding, too.** 0.18.1 took the overlay down on the next pass over
  the open matches, which, where the relay pushes those matches rather than
  the tab reading them itself, runs when the pushed document changes and at no
  other time. The document that removed the finished match is the one that
  armed the overlay, so on a plane where nobody else happened to create or fill
  a match in the meantime no further document came and the overlay stood
  exactly as it had before: the create card and every Join row unreachable
  until a reload. A lobby with a fill outstanding now watches the chain for as
  long as that fill is outstanding and lets it go on the block that settles it.
  A fill the chain has already outlived may raise no overlay at all: that
  needs the GSP to be at least a block ahead of the node that answered the tip,
  and short of that the usual course is an overlay raised for one block and
  taken down by the next. A lobby with nothing outstanding watches nothing and
  is unchanged.
- **A match that really is starting keeps its overlay in two cases 0.18.1
  could cut short.** The block the overlay is settled against is read from the
  chain alongside the match itself, and on a load-balanced endpoint that answer
  can be one block behind the start it is bounding, so the bound now allows
  for that, at a cost of at most one extra block of overlay. And where that
  read fails outright, the overlay is raised anyway and held until the channel
  opens, as it was before 0.18.1: the player who has just filled a match is
  shown the match starting rather than the lobby they thought they had left.

## 0.18.1: 2026-09-02

Not breaking: one fix to the end of a paid match. Vendor it over 0.18.0 with no
code changes of your own.

- **A finished paid match no longer leaves its "Match starting…" overlay over
  the lobby.** Play a wagered match to a close and come back through the recap,
  and the lobby could be covered by the start overlay for the match just
  finished (its seats, its pot, "Waiting for the arcade referee to open the
  channel…") over a lobby that already showed the result, with the create card
  and every Join row unreachable behind it until the page was reloaded. That
  state is the bridge between a confirmed fill and the channel it opens, and it
  was only ever taken down at one end: our channel being open. A fill confirmed
  once the match was already over (a poll that noticed the filled match late,
  a receipt read after the fact) had no channel left to clear against and so
  stood for good. It is now armed with the block that settles it, and dropped
  once the GSP has reached that block with no channel of ours in the export:
  the channel is opened by the very transaction that starts the match, so past
  that block an absent channel means the match is over, not merely unindexed.
  Nothing about the money or the match itself was affected: the stake was
  settled and the result recorded exactly as they read, and a fill still
  carries the player who filled it onto the board.

## 0.18.0: 2026-09-02

The player who ends a match themselves is told the result, and a game can word
its controls hint for the device reading it. **BREAKING** only for code that
READS `adapter.controlsHint` as a string: every game repo's own adapter test
does, and the fix is one line each; the field's declaration is unchanged.

- **The player who forfeits is told they lost.** Every other way a match can end
  puts a result on the board and holds it there until the player presses Back to
  Lobby, but pressing "Close (Forfeit)" returned them to the lobby immediately,
  with nothing said and a loss quietly ticked onto their W/L chip, while their
  opponent got the full "You Win! / Match settled. / Your opponent forfeited. You
  won." overlay. The forfeiter now gets the same end-of-match screen as any other
  loser: "You Lose!", the reason ("You forfeited: p/*name* wins."), and the one
  Back to Lobby button that leaves it. It is derived from the close this player
  just submitted, so it is up the moment the button is pressed rather than
  waiting on a chain record that lands blocks later (and in a match of more than
  two seats, where the channel stays open behind them, it reads "You left) the
  match continues without you.", and once the dispute window takes the seat,
  "Your seat has been timed out.", rather than settling forever against a
  channel the survivors are still playing in. A leave the wallet rejected, or one
  whose timeout did not land on our own seat, shows no recap at all: nothing
  happened, and the player is still in the match. A leave handed over by the
  lobby (where the board was entered for no other purpose) still returns there
  when it lands. And where the settled close names this player the WINNER (both seats quit in the same block and the other one landed first) the chain's
  record is what the screen shows, not the forfeit we were in the middle of.
- **`controlsHint` can be worded per device.** The hint renders directly above
  the on-screen pad on a phone, so a single keyboard-worded line printed "WASD
  move, Space bomb" over a d-pad. The field now takes either a string (shown
  everywhere, exactly as today) or a `{ keyboard, touch }` pair, and the SDK
  picks by the same coarse-pointer gate that mounts the pad: on the board and in
  the standalone menu. Existing string hints render exactly as they did.
  **BREAKING** for anything that READS `adapter.controlsHint` as a string:
  `.length`, `.toContain`, passing it where a `string` is required, because the
  declared type is now a union and TypeScript refuses the member access
  (TS2339). Every game repo's own adapter test does this today:
  `tests/lib/games/xayaman-adapter.test.ts`,
  `tests/lib/games/xayatrails-adapter.test.ts`,
  `tests/lib/games/xayaships-adapter.test.ts` and vector-sumo's
  `tests/hooks/game-input-pump.test.ts`. Fix a reader either by narrowing
  (`typeof hint === 'string'`) or by resolving it first:
  `resolveControlsHint(hint, false)` is exported for exactly that and gives the
  keyboard wording. When you do add a touch wording, say the same things
  about the game in the terms that device offers, and keep both lines short
  (about 46 characters fit one line on a 320 px screen). Suggested touch copy for
  the games that ship a pad: xayaman "Last one standing wins · tap the pad to
  move, ● to bomb"; dungeon "Last champion standing, or shrines at round 384 ·
  pad to move, buttons to act"; xayatrails "First to 2 round wins · swipe or use
  the pad". Vector Sumo's controls are its own, and its hint already reads
  correctly on both.
- **Internals de-duplicated, with no behaviour change.** Repeated code inside
  the wager hook, the lobby, the board, the notice lists and the on-chain move
  senders was folded into shared helpers; nothing a game calls behaves
  differently. Two dead things went with it, and only a custom shell that
  imported them directly is affected: `onGspUpdate()` (a GSP-state callback
  nothing ever registered) is gone from `hooks/use-gsp-polling`, and
  `MatchOutcomeInput` no longer declares `lastDisputeTurn` or `numParticipants`
: `deriveMatchOutcome` stopped reading either when the host became the only
  authority on an undecided close.

## 0.17.2: 2026-09-02

Not breaking: a paid match that filled but never opened for the player who
filled it, plus two more fixes to the leave seam 0.17.1 repacked. Vendor it over
0.17.1 with no code changes of your own.

- **The player who fills a paid match reaches the board again.** Their own join
  is what completes the roster, so the referee can have the channel open (and
  the lobby showing "Your Active Game / Resume Game") before their join receipt
  has even been read. Both halves of the handover were written for the other
  order and stalled on this one: the "Match starting…" state only cleared on the
  channel arriving, so a fill confirmed after it stood for good, and the overlay
  it draws takes every click meant for the board behind it; and the entry onto
  the board was re-tried only when the channel list changed, which for this
  player had already happened for the last time. The confirmed fill now clears
  against a channel that is already open whichever landed first, and it carries
  the player onto the board on its own. Match, stake and payout were never
  affected: the game was open the whole time, and re-entering the tab resumed
  it, but the player was locked out of it until they did.
- **A leave with no wallet behind it now says so, and happens when the wallet
  comes back.** Disconnecting the wallet after the board is up leaves nothing to
  sign a close with, and both routes into it went quiet: the Leave button did
  nothing at all when pressed, and a leave handed over by the lobby was refused
  and then never reconsidered, because the signer was not one of the conditions
  the handover watched. The refusal now tells you to reconnect and leave again,
  and reconnecting is itself enough: a handover that was waiting on the wallet
  carries the leave out as soon as it returns.
- **The "not joined to the match yet" notice no longer repeats per relay
  reconnect.** A reconnect restores the shared socket and re-joins this channel
  on it in two steps, and for the gap between them a leave waiting on the relay
  looked ready to run: it was attempted, refused for the missing join, and the
  notice raised: once for every reconnect attempt, none of them able to
  succeed. The handover now waits for the re-join to ack instead of asking. A
  socket that is genuinely dead is still caught, and still says so.

## 0.17.1: 2026-09-02

Not breaking: a repack of 0.17.0's leave seam, plus one alignment fix. Vendor it
over 0.17.0 with no code changes of your own.

- **A leave can no longer file on a dead link.** The check that refuses a leave
  while this channel is not joined on the relay read a flag that nothing clears
  when a shared relay socket dies: for the whole outage (the drop, the backoff,
  every retry until a replacement socket is handed over) it still answered
  "joined". The re-check after the wait for your seat was the one that mattered,
  and it was blind in exactly the case it exists for: the link up when you press
  Leave, gone by the time your seat came round, the stillness that satisfied the
  wait nothing but your own deafness. The dispute then landed on a tip the
  players still at the board had moved past, ejected nobody, cost a transaction,
  and left you marked as having left a match you were still in. The question is
  now answered from the socket itself, so that leave is refused and can simply
  be pressed again once the relay is back.
- **A refused leave stops repeating itself.** The lobby's "Leave" carries the
  instruction onto the board, and a refusal correctly keeps it standing for
  another go, but the retry was wired to every arcade-wide state update, which
  arrives several times a minute and changes nothing about why the leave was
  refused. The result was the same "not joined to the match yet" notice raised
  over and over for as long as the join stayed down. It is now retried when a
  refusing condition actually clears: the relay join acking, your link coming
  back, a dispute of yours landing, and once each time. A leave that finds no
  wallet or no channel to address is also a refusal now, rather than silently
  consuming the instruction and returning you to the board.
- **The sideways controls hint lines up with the pad.** Held sideways the hint
  shares the on-screen pad's gutter, but sat 4px further in than the pad, so the
  two read as misaligned rather than stacked. Both now come from one inset.

## 0.17.0: 2026-09-02

**BREAKING** for an app that builds its own board screen on `useChannelManager`
(no shipped game does: games render `ChannelGame`): its `moneyErrors` /
`dismissMoneyError` are now `sendErrors` / `dismissSendError`, and they carry
every failed on-chain send rather than a paid channel's only. Rename the two
fields; nothing else about them changed.

- **The SDK can own a square board's frame.** Two games had grown
  byte-identical copies of the same container-query CSS: the board is the
  largest square that fits both axes, and on an upright phone the frame reserves
  the strips the status line, the on-screen controls and the controls hint sit
  in. A game can now declare `presentation.squareBoard: true` and delete its
  copy: the SDK renders the frame around the game's renderer and supplies the
  stylesheet. The strip for the status line is reserved on any upright touch
  screen, because the status line is drawn over every channel; the band below is
  reserved only for a game that declares touch controls, and off the declaration
  rather than the live pad, so the board does not resize each time the pad
  unmounts. Opt-in and inert otherwise: a game that sizes itself (side-by-side
  boards, a fixed-ratio scene, an arena that fills the frame) is untouched, and
  so is every fine-pointer layout.

  **Migrating a renderer to it**, in the order the mistakes are made: delete
  only your own frame and surface rules (`.board-frame`, `.board-surface`) and
  return the board CONTENT: the wrapper element goes away, the SDK renders the
  frame in its place. Put `class="arcade-board-surface"` on the surface that used
  to carry your square sizing; that is the one class the SDK's stylesheet acts
  on. Anything that MEASURED the old wrapper (a `ResizeObserver`, a
  `getBoundingClientRect` for canvas pixel sizing) must observe the surface or
  the canvas instead: the element it was watching no longer exists, and an
  observer on a vanished node reports nothing rather than failing loudly. Keep
  `.play-surface` and every other class of your own exactly where it is; the SDK
  neither reads nor writes those.
- **A failed on-chain send is now said out loud, at any stake.** The transaction
  that files your dispute, resolves one, or submits the win could fail: a
  wallet on the wrong network, an RPC refusing an oversized payload, and the
  player was told nothing: the reason went to the browser console and the click
  simply appeared to do nothing. Free-play channels got a toast that named no
  cause; paid ones got a persistent notice; a failed send during a match got
  neither. Every one of them now lands in the in-match notice column with the
  status the sender reported and what to do about it, and a failure that repeats
  is stated once rather than stacked. A send that DOES go out clears the column,
  so the same failure arriving after a working send is heard as the new thing it
  is rather than folded into the notice already on screen.

- **A renderer can now see which seats the chain has ejected.** The channel
  store publishes `ejectedSeats: number[]` for the current channel, from the
  GSP's own export. It is the one fact about who is still playing that nothing
  else carries: the board JSON has no notion of an ejection, and the GSP never
  edits the participant list, so a game working from the roster keeps drawing a
  player timed out of the match. Empty means nothing known (an older GSP omits
  the annotation), and the last known list stands once the channel leaves the
  open-set: a close does not un-eject anybody. The adapter contract lists it
  alongside `matchOver`, `linkDown` and `opponentDisconnected`.
- **A dropped opponent is announced when they drop.** The only plain-language
  notice a player got was the one attached to the dispute offer: a grace period
  later, and only when the round had parked on a seat that was not theirs. An
  opponent who closed their tab during YOUR turn was never mentioned at all: the
  board simply sat there. The board now says it as soon as the relay reports it
  ("Opponent disconnected", or "A player is not connected" above two seats,
  where the flag cannot say who), and folds that notice away when the dispute
  banner takes over. The raw `PEER:DC` telemetry stays behind the debug flag.
- **A join whose retry never sent stops reporting the reverted attempt.** The
  retry behind a reverted join fell back to the first attempt's transaction hash
  when it sent nothing itself: a cancelled second prompt, or a pre-flight read
  that threw. A hash is how this call says a transaction of ours went out, so
  the lobby held its controls on a transaction already known to have reverted:
  the step stayed marked as sent, with no retry offered and no way out but a
  reload. Only an attempt that actually went out reports a hash now.
- **A leave that DID eject your seat no longer tells you to play on.** The
  answer a leave returns is about the tip its dispute was filed on, and it had
  picked up a second, unrelated doubt: whether a peer's proof had arrived since
  the board opened. The last player standing (the round parked on their own
  seat, everyone else long gone) is exactly the case where none ever does, so a
  correct self-ejection was reported as "filed against the seat on the clock
  instead, play on". Moves resumed against the player's own dispute, their own
  client resolved it away, and the seat was never removed: two transactions of
  gas per attempt, and every retry the same. The tip filed on is now the whole
  answer. The doubt it replaced is handled where it belongs: a leave is refused
  outright, before it files anything, while this channel is not joined on the
  relay (through a socket delivering nothing every tip looks still) and says
  so, exactly like the refusal when your own connection is down. The same check
  runs again on the way OUT of the wait for your own seat, which takes seconds
  and is long enough for the join to go; the tip it settled on would then be one
  the players still at the board left behind.

  Every refusal now says why. A leave pressed while a dispute of yours is still
  being submitted was a guaranteed no-op: filing is blocked for the whole
  window, and it bailed in silence, so the button read as broken; it says what
  is happening and when to try again. And a refusal no longer eats the LOBBY's
  leave: that button hands the board a one-shot instruction to leave, and
  spending it on a refusal (a relay join still in flight, which is the usual
  state a moment after the board opens) dropped the player back into a match
  they had asked to leave with nothing said. A refusal keeps the instruction and
  the board runs it again once the join lands; only a leave that was really
  attempted spends it.
- **A multi-seat match no longer accuses the seat on the clock of dropping.**
  "A peer disconnected" is one channel-wide flag with no seat in it, so at three
  and four seats the waiting banner pinned it on whichever seat the rotation had
  reached: a player sitting there perfectly connected. Above two seats the drop
  is now stated without a name, and the seat is mentioned only as the one a
  dispute would put on the on-chain clock (which is all that was ever true of
  it). Two-seat channels are unchanged: there the one other seat IS the peer
  that went. The dispute offer itself is unchanged at every seat count: it has
  always targeted the seat on the clock, because that is the only seat a timeout
  can remove.
- **The controls hint survives the on-screen pad.** A game that declared touch
  controls had its hint hidden outright, on the grounds that key names mean
  nothing on a phone. But that line is also where a game states its win
  condition, so the rule was invisible on exactly the devices with no other
  place to read it. The hint now renders on every device: on touch it moves out
  of the pad's corner and sits one step above the controls: running across the
  frame upright, and staying in the pad's own gutter when the phone is held
  sideways, where a full-width line would cross the board itself. Write
  `controlsHint` for both audiences: the keys AND what a player still needs
  when the keys are irrelevant, and keep it short: about 46 characters fit one
  line on the narrowest screen the arcade supports.

- **A join holds the lobby until it is finished, retry included.** The hold
  ended the moment the transaction was broadcast, leaving every Join button live
  through the receipt wait behind it: up to three minutes. A player who pressed
  something else in that window turned the automatic retry into a silent no-op
  that reported the REVERTED transaction as the join's result, and one whose
  retry did land could end up seated in two lobbies at once. The whole call now
  holds, and the revert that triggers the retry is said out loud before a second
  wallet prompt appears rather than after it.
- **A staked join no longer sends a thinner gas limit than the wallet would
  have.** Supplying an explicit limit replaces the wallet's own buffer, and for
  a lobby-filling join the queue-walk headroom was the smaller of the two, so
  the transaction that pays out every seat of the landing group was the one sent
  with the least margin. The limit is now whichever is larger.

- **One 2-player close, used by both screens.** The board and the lobby each
  built their own declare-loss move. They agreed today: the lobby finds the
  seat BY the live name, so the two can never differ there, but only the
  board's read the signing name and the reinit off the channel's own metadata,
  which is what consensus checks and the one place a switched identity shows up.
  Both now call the same close (`forfeitChannelOnChain`, exported), so there is
  no second copy left to drift.
- **A board update queued as the screen closes is dropped, not delivered late.**
  Board states are coalesced and published on a timer; the timer survived the
  board unmounting, so the old channel's last frame could be written into the
  store after the player had left it, and into the next channel they opened.
  The adapter contract now also says outright that the published state is
  cumulative: intermediate states of a burst are never delivered, so a renderer
  must read what the state says rather than count updates.
- **A leave handed to the board can no longer land on the wrong channel.** The
  lobby set the "carry this leave out" flag before the entry it belongs to had
  passed its own guards, so an entry that returned early left the flag standing
  and the next channel the player entered was left out from under them. It is
  now part of the entry itself, stated either way: a resume clears it.
- **The agreed-table watch needs an export at least as new as the table.** A
  relay-cached state older than the height the table was seen at is missing that
  table for the same reason it was missing the day before, and the banner read
  that as "p/x cancelled the table", retiring a live agreement (and, at a stake,
  leaving money standing in a match it had just told the player to walk away
  from).
- **"Confirmed on-chain: setting up your match…" now has a way out.** It clears
  only on a failure, and a confirmed transaction has none coming, so a table
  that never reached the export left that line up until the page was reloaded.
  After a minute it falls back to the spent line.
- **A catching-up GSP no longer ends a live match on screen.** Resuming into a
  match, the board called it closed as soon as one full export had been applied
  without the channel in it, but an export from a GSP that is behind its own
  chain shows the channel set as it stood at an older height, where a channel
  that had not opened yet is missing exactly as a closed one is. It now waits
  for a current export, at any stake.
- **A stale chain view no longer reads as a dropped connection.** An idle chain
  (or a wedged upstream) raised "Reconnecting: your connection to the match
  dropped" while proofs were flowing perfectly well and moves were going
  through. The banner and the store's link signal are about YOUR connection
  alone now; a stale height still withholds the dispute offer (the clock counts
  in blocks) and still shows its own note on the dispute panel.
- **A result the leaderboard cannot attribute is no longer claimed.** The
  win/loss shown after an undecided close is read from your own leaderboard row
  moving by one, and that row is keyed by name across every game on the GSP:
  so a name seated in two open matches at once could be shown the other match's
  result as this one's. Where a second match of yours was open, the close now
  says nothing rather than something wrong.
- **A multi-seat leave that did not remove your seat no longer says it did.**
  When the round never came round to the leaver inside the bounded wait, the
  timeout went out against whichever seat WAS on the clock: the survivors
  answer that with a newer state, nobody is ejected, and the board still marked
  the channel left, said a timeout had been filed against your seat, and sent
  you back to a lobby that offered no way in. The dispute still goes out (it can
  time out a genuinely absent seat), but the player is told what it actually did
  and stays in the match. A leave is also refused outright while your own
  connection is down, and a tip nothing has moved is no longer taken as evidence
  the round reached you unless a peer has been heard from at all: through a dead
  socket every state looks still. Once the chain says your seat has already been
  ejected the board stops offering the leave at all.
- **Leaving a multi-seat match now removes YOUR seat.** The lobby's "Leave
  (Forfeit)" filed a timeout on the last state the chain had seen, which ejects
  whichever seat happened to be on the clock there: usually not the leaver's.
  The other players simply answered it with a newer state, nobody was ejected,
  and the leaver sat on "settling on-chain" while the survivors were told to
  file a dispute of their own. The leave is now carried out on the board, the
  only place the live state exists: it waits for the round to reach the
  leaver's seat and files there, so that seat is the one the expiry ejects. The
  screen says so while it happens, and the lobby's own explanation matches.
- **The last player standing is told the match is theirs to finish.** With
  every other seat timed out, the lobby still listed the ejected players as
  opponents and offered a leave that promised to eject "the seat on the clock"
: there was none left. It now says every other seat has gone and points at
  the only thing that can still close the match: playing it to its end, which
  settles it on the result.
- **The agreed-match banner stopped announcing a played match mid-handoff.**
  The agreement is spent the moment its transaction confirms, but the table it
  opened reaches the chain view a poll or two later, and in that gap the banner
  told a player whose match was starting to go and find another game. It now
  says the match is being set up, and keeps the spent line for a visit where
  nothing of ours is in flight.
- **A joiner is told when the table they agreed on ends without them.** Waiting
  for a peer's table that had already filled with a stranger, or that the peer
  cancelled, read as "Waiting for p/x to create the game…" indefinitely. The
  chain's record of the exact table that was watched now decides: it filled
  without you, or they cancelled it, and the agreement is retired with it, so
  a later table of theirs is not joined on your behalf.
- **A table you merely took a seat in is no longer described as yours.** It was
  headed "Your Game" with a "Cancel Game" button, and only the player who
  opened a table can cancel one: the move was dropped by consensus. A seated
  joiner now sees whose table it is and what happens next.
- **An embedded lobby handed one agreed match shows that match alone.** A
  `?mm=` handoff rendered the game's whole lobby around the single card that
  mattered: a second identity chip, a create card, an open-games list to be
  avoided, a leaderboard. While the agreement is live, only the agreed match is
  drawn (with the cancel for a table of your own on that card); the ordinary
  lobby comes back the moment the agreement can no longer be honoured, ends, or
  is spent with nothing of yours standing. Standalone is untouched. Raw channel
  ids are gone from the lobby with it.
- **The winner of a forfeit or a dispute timeout is now told they won.** Those
  closes never set the board's `finished` flag: the match is settled on-chain,
  not played out, so the end screen fell through to a red "Game Over / This
  match has closed." on the side that had just won, and a paid winner was shown
  no payout line either. The result is now read back from the chain's own
  record of the close: the GSP writes won+1 to the winner and lost+1 to every
  other seat when it settles a match, and exports that leaderboard on every
  state push, so the delta of the player's own row across the close says what
  happened. Where the chain has no readable answer (a draw, an abort, a row
  that moved by more than this one match) the screen still says only that the
  match closed: it never guesses. Games get `matchOver` on the channel store
  alongside it, so a renderer can stop drawing turn prompts and control hints
  over a match that has ended.
- **A channel that no longer exists resolves to a result, not a spinner.** A
  player who was away when their match ended: tab closed, browser quit, lost
  by timeout: came back to "Connecting to channel…" forever, because the
  channel they were resuming was already gone and that client had never seen it
  open. An absence confirmed against a current GSP export now ends the wait
  within a few seconds and shows the outcome, read the same way as above.
- **"Your opponent has gone silent" is no longer shown to the player whose own
  connection dropped.** A client with no network saw no sign of trouble at all
  and was then offered "File Dispute: claim the win" against a perfectly
  healthy opponent, which is an action that puts the clock on the accuser and
  loses them the match. The relay socket being down (and the browser's own
  offline signal, which arrives immediately: a socket with nothing to send can
  stay nominally open for minutes after the network under it dies) now shows a
  reconnecting state instead, and suppresses the dispute offer for as long as
  it is up. `useGspPolling` exposes it as `linkDown`, and the channel store
  carries it for a game's own renderer.
- **The in-match HUD stopped talking to developers.** `net:`, `turn:`, `gsp:`
  and `PEER:DC` were the status line every player saw; they are behind the SDK
  debug flag now (`NEXT_PUBLIC_DEBUG_CHANNEL=1`, or the `_debug` storage key),
  and what remains is plain language. "Close (Forfeit)" and the controls hint
  no longer sit over a finished match, the free-play close recap no longer
  tells a player to check a balance they never staked, and the status line and
  the buttons share one row so that at phone widths the line wraps below them
  instead of running underneath them.
- **A burst of applied proofs no longer turns into a chain of renders.** A
  client rejoining a live match replays its whole backlog of state proofs in one
  synchronous run, and every one of them was published to React: updates
  scheduled from inside the previous one's commit, which React refuses to nest
  more than fifty deep. The burst ended in "maximum update depth exceeded",
  thrown inside the channel manager's own callback and swallowed by its
  try/catch, leaving only a "Callback error" line in the console (3 of 3 tab
  reopens on a fork; 0 of 3 after). Only the last state of such a burst can ever
  be painted, so that is the one published, once the burst is over. The dispute
  view is handed back unchanged when nothing about it moved, too: it was rebuilt
  as a fresh object on every net tick, re-rendering every consumer several times
  a second for no change.
- **The remaining lobby writes read their own receipts.** Leave, abort, expire,
  remove-a-stale-seat and refresh-the-queue are all dry-run before signing, so
  a revert that reaches a block is a race: the last seat filled, someone else
  expired it first, the queue settled. Each said nothing and, worse, cleared
  its own tracking as though it had worked; each now reports what did not
  happen and leaves the lobby's state alone. A paid join also asks for gas
  headroom sized to its snapshot's depth: the contract walks past payout groups
  settled since the estimate was taken, which is work the estimate never priced.

- **A pushed state now costs only what changed in it.** The relay sends the
  whole game state whenever anything on the plane moves: on a public arcade
  that is most blocks, because somebody is always playing, and the client
  rebuilt the entire parse every time: a fresh channel map, and a freshly
  decoded state proof and reinit blob for every channel, kilobytes apiece.
  Almost none of it was new (a live plane changes a few hundred bytes of one
  channel out of ninety kilobytes), and none of it was released either: a
  callback React memoises across a render keeps that render's whole set of
  values alive, and each render's values include a memoised callback from an
  earlier render, so the renders form a chain that only grows: one entire
  parsed state pinned per push, for as long as the tab stayed open. A signed-in
  lobby left open in a background tab grew by tens of kilobytes per pushed
  state, ~140 KB a minute on a busy plane, and never gave any of it back.
  Consecutive parses now share every channel and every collection whose
  exported JSON is byte-identical, so a retained render holds the same objects
  the live one does and owns only what genuinely moved since; a push that
  changed nothing hands back the previous collections whole, which React bails
  out on rather than re-rendering. `parseGameState` takes an optional
  carried-over cache (`newGspStateCache()`); called without one (as a single
  read does) it parses independently, exactly as before.

## 0.16.5: 2026-08-30

Not breaking. This entry also covers 0.16.1–0.16.4, which were superseded
before any consumer vendored them and have no separate entries. One live
defect fixed, and it is the reason a match could
fill on-chain and then never start.

- **The relay socket now recovers from a close the server sent.** `onclose`
  reconnected (and fell back to polling the GSP directly) only when the close
  code was not 1000. But 1000 is "normal closure", which a server sends too:
  the relay closes the socket a re-join supersedes, which is reached whenever
  two sockets hold one seat at the same moment: a second window of the same
  game, or an old socket left half-open by a network drop or a sleeping laptop,
  whose close the relay has not seen yet. Read as the client's own hang-up,
  that close ended the feed for the rest of the page: no reconnect, no fallback
  poll, `status` still reading connected, and the `heightStale` watchdog unable
  to fire (it requires an OPEN socket). The client kept the last channel map it
  had, never learned its own match had filled, and could neither send nor
  receive a state proof. Nothing on the close event distinguishes the two
  cases, so nothing is read off it any more:
  `disconnectWs()` detaches the handler before closing, so every close that
  reaches it is one the client did not ask for, and every one of them
  reconnects.

  Pair this with a relay carrying the matching change (superseded sockets close
  with 4001, not 1000). Either half alone fixes the observed failure; both make
  it unreachable.

- **Reconnects back off, 3s doubling to 30s.** A single outage still recovers
  at the first, shortest delay: unchanged. The doubling bounds the one case
  reconnecting-on-everything opens up: two windows of the same game hold one
  seat between them, and each one's re-join supersedes the other's socket, so a
  fixed retry has them trading it back and forth forever. The delay returns to
  the minimum once a socket has held for ten seconds; a socket that merely
  OPENS does not reset it, because every socket in that fight opens fine. The
  client loses nothing while it waits: the direct GSP poll keeps chain state
  flowing for as long as the socket is down.

- **The own-socket relay client reconnects with the same backoff.** Its flat
  2s retry becomes 2s doubling to 30s, reset only after a socket has held for
  ten seconds: never on the join itself, since in a two-client seat fight
  every socket joins fine and is superseded a moment later.

- **The channel layer never closes a socket it does not own.** `WsBroadcast`'s
  `connect()` disconnected any existing socket by nulling its handlers and
  closing it. In SHARED mode that socket belongs to the polling hook, which
  holds the `onclose` that reconnects it, so this would have taken the page's
  whole chain feed down with nothing left to notice or restore it. It lets go
  of the reference instead. Its own reconnect gate also tested for close code
  1000 with reason `'disconnect'`; both deliberate closes on that path already
  detach the handler, so that test only ever stood between the client and a
  close the server sent.

## 0.16.0: 2026-08-27

**BREAKING, in one list.** Every one of these changes a signature, a return
value or an acceptance rule a consumer may already depend on:

- `paymentKeyOf(bet, numPlayers, matchId, payee, amount)`: five arguments.
- `joinMatchOnChain(..., queueHash, expectedMatchId)`: five arguments.
- `buildSecurityHeaders(frameAncestors?, opts?)`: a second, optional argument,
  and the policy it produces is narrower.
- `isSigningAddrSafe(v)`: a signing address must now be an address, in EIP-55
  canonical form. The old rule accepted any printable ASCII.
- `SignatureVerifier.recoverSigner` returns `string | null`; a custom verifier
  must widen its return type, and an unrecoverable signature must answer
  `null` rather than a placeholder string.
- `ChannelManager.getPlayerIndex()` resolves by player NAME first and by
  signing address only as a fallback.

**BREAKING: the wager client now speaks ArcadeWager v2, and only v2.**

The contract's replay key gained the payout amount, a join now names the queue
group it consents to settle, and a seat whose player name moved away can be
removed by anyone. Every wager surface in this package mirrors that:

- `paymentKeyOf(bet, numPlayers, matchId, payee, amount)` takes a fifth
  argument and `PAYMENT_KEY_PARAMS` (now exported) encodes five fields.
  Without the amount, a payment of one wei marked a queue row settled forever
  while the GSP (which always keyed prepayments on the amount) went on
  expecting the row to be paid in full, wedging the pooled queue for every
  game at that (stake, seats).
- New `paidSetKey(entry)` is the ONE membership key for paid-set state
  (`readPaidSet`, `paidCheckEntries`, every `isPaid` closure): the same payee
  and matchId at two amounts are two independent answers.
- New `storedFrontMatchId(stored, isPaid)` names the group a snapshot would
  pay right now. `isFrontAnchored` returns `{ anchored, frontMatchId }` from
  its single paid-set read instead of a bare boolean, and
  `joinMatchOnChain(..., queueHash, expectedMatchId)` binds the join to that
  group, so a front consumed between reading it and the fill landing reverts
  the join instead of paying whichever group the walk now reaches.
- New `readMatchConsent(address, matchIdx)` reads what the seats already taken
  agreed to settle (null while no paid seat has joined); `useArcadeWager`'s
  `join()` checks it before prompting a wallet for any seat after the first.
- New `evictSeatOnChain` / `findEvictableSeat` and a `useArcadeWager`
  `evictSeat(match, seat)` action, surfaced as "Remove stale seat" in
  `WagerPanel`: a seated wallet that no longer controls its player name used
  to freeze the lobby's stakes until it expired. New `isSeatNameError(text)`
  spots the two refusals that mean a client's picture of the lobby's seats is
  stale, from the copy alone: `WagerPanel` uses it to offer the removal on
  the row a join was just refused for, since eviction is permissionless and
  needs no seat of your own.
- `ArcadeWagerState` gained `canEvictSeat` and `evictSeat`. `evictSeat` is also
  a bridge op: `WAGER_OPS` gains `'evictSeat'` (appended, so no existing op
  moves) carrying `matchIdx` and a `seat` integer, and an embedded game brokers
  the removal through the shell exactly like every other op: it is
  permissionless on the contract, but a game in an iframe holds no wallet to
  send it with. `canEvictSeat` is therefore true wherever wagering is enabled.
  **The Arcade shell must be on 0.16 before games are re-vendored against this
  release**: a shell that predates the op drops the request in its parser, and
  the game would be offering a button whose only outcome is a 20 s timeout.
  `WagerBroker` bounds that one op at 20 s (`the arcade did not answer the
  eviction request`) so an old shell costs a message rather than a wedged
  client: every other wager op still waits indefinitely, because it is a
  wallet prompt a player may take minutes over.
- `WagerPanel` latches which row it offers the removal on. It used to be
  derived from whether the refusal was still on screen, so dismissing the
  message retracted the button; the offer is now let go only when the row
  leaves the lobby or the contract says there is no seat on it to remove.
- A FREE join sends `expectedMatchId` as the zero hash explicitly. A free lobby
  settles no payout group and the contract reverts a non-zero consent on one.
- `checkWagerContract` accepts version 2 EXACTLY. A v1 deployment now fails
  the gate: its four-field key would answer "unpaid" for every row this
  package asks about.

Games must be rebuilt against the redeployed contract; a build carrying the
old client against the new address (or the reverse) reads the payment queue
wrongly and must not be pointed at either.

**One public RPC, and it is ours.**

The read-RPC fallback pair quietly included a third-party endpoint
(polygon-rpc.com) alongside the operator's own node, both in the default
`getChainRpcUrls()` list and in the `wallet_addEthereumChain` payload and CSP
`connect-src` this package ships. That third party is gone from all three: the
unset-env default is now `[polygon-node.xaya.io]` alone, the wallet's chain-add
call only ever offers the operator's node, and the shipped CSP no longer
allows the browser to reach polygon-rpc.com at all. The `fallback()` transport
wrapper stays in place around the (now single-entry) list: this is a policy
change to what's in the list, not a retry-semantics change.

Not breaking: `getChainRpcUrls()` keeps its shape (an array of strings); a
consumer already handling zero or one entries needs no changes. An explicitly
configured `NEXT_PUBLIC_POLYGON_RPC` (or runtime `chainRpcUrl`) is unaffected:
this only touches the unset-env default pair.

A fourth place named a third party too, and it wasn't reachable through
`getChainRpcUrls()` at all: `wagmiConfig`'s own `chains` entry. A connector's
generic switch-chain path reads `rpcUrls` straight off that chain object, not
off the `transports` map, and the non-dev-wallet branch left it as the
vendored viem's stock `polygon`: whose own default RPC is a third party:
untouched. It now always names an operator-controlled URL: the resolved fork
RPC in the dev-wallet branch, `DEFAULT_POLYGON_RPC` (now exported from
`service-urls.ts`) in every other case. Also not breaking: the chain's other
fields (id, name, contracts, block explorers) are untouched, only `rpcUrls`.

**A signing address is one address, in one form, on one seat.**

`isSigningAddrSafe` (both `protocol.ts` twins) now requires `0x` + 40 hex in
EIP-55 canonical form, and nothing else. The referee compares its recovered
signer against the seat's stored address in checksummed form byte for byte, so
any other spelling produced a seat whose signatures verified in the browser and
never on chain: a dead seat whose disputes are unprovable and whose stake is
lost by timeout. The old filter admitted any printable ASCII, including a
literal placeholder that every unrecoverable signature would satisfy.

Alongside it: `EthSignatureVerifier.recoverSigner` answers `null` instead of a
placeholder string (a placeholder is a value, and a value can be seated), and
`verifyParticipantSignatures` skips a null rather than matching it against a
seat. `ChannelManager.getPlayerIndex()` resolves by player NAME first, falling
back to the signing address, and never refuses on a duplicate: nothing off
chain stopped two seats carrying one address, and an address-first lookup then
handed this client the OTHER seat's index, deadlocking it against the
name-derived seat every game already uses, and a client that produces no move
is the one that gets timed out. `useArcadeWager`'s `join()` and `ChannelLobby`'s
join refuse a lobby that already seats this client's signing address, before any
read or wallet prompt (`SIGNING_ADDR_SEATED_COPY`), and a GSP channel counts as
this client's own only when the seat carrying its address is also in its name:
a stranger could otherwise seat the (public, stable) address in a channel of
their own and stall the victim's whole paid lobby feed.

**A padded proof is refused before it costs anything.**

`verifyParticipantSignatures` returns an empty set when a `SignedData` carries
more signatures than the channel has seats, before the first recovery. Every
extra entry cost a full secp256k1 recovery and at most one seat per entry could
ever be credited, so an opponent could bill a tab thousands of recoveries per
frame at no cost to themselves. No honest producer emits such an array, and the
referee applies the same bound. `verifyStateProof` also recovers each
transition's signatures once instead of twice: the transition check returns the
signer set it already derived, as the C++ twin has always done.

**A full relay channel is retried, and a failed relay join is a real retry.**

A channel the relay has not yet learned about from GSP state admits anyone, so
its seats can be held by strangers for the moment between the channel opening on
chain and the relay learning who belongs in it. `WsBroadcast` now replays a
freshly signed join after a 2 s backoff on `Channel is full`, bounded by the
join timeout that was already there, on both the shared-socket and own-socket
paths. And `useChannelManager`'s `initialize()` tears the half-built channel
down when it throws: the manager reference was set before the relay join and the
guard at the top of `initialize()` returns early whenever it is set, so a failed
join turned every later retry into a silent no-op: a client holding a manager,
never ready, with no relay membership.

**The browser judge asks for a zero-length buffer at its true length.**

`packed-judge.ts` called `arcade_alloc(len || 1)`, padding an empty move, state
or cfg to one byte, while the wasmtime host asks for the real length and refuses
a zero answer even there. A blob whose `arcade_alloc(0)` returns 0: a naive
`malloc(0)`: was accepted in the browser and rejected on chain for the same
input. Both judges now call `arcade_alloc(len)`, and free with the length they
allocated with.

**The game CSP names origins instead of granting schemes.**

`buildSecurityHeaders(frameAncestors?, opts?: { connectOrigins?: string[] })`.
The bare `wss:` and `ws:` sources are gone: they permitted every socket
destination on the internet, which is the grant a compromised bundle would use
to ship a session key somewhere quiet. `connect-src` is now the fixed set (the
WalletConnect sockets named explicitly) plus `opts.connectOrigins` plus the
origins of `NEXT_PUBLIC_RELAY_URL` / `NEXT_PUBLIC_GSP_URL` /
`NEXT_PUBLIC_POLYGON_RPC`, deduped, with anything that is not an absolute URL
dropped. `form-action 'self'` is added, and a `frame-ancestors` rule is now
always stated (`'none'` where `X-Frame-Options: DENY` was previously the only
thing said). `script-src` is untouched: the in-browser judge needs
`'unsafe-eval'` for `WebAssembly.instantiate`.

**The lobby's fallback read is a couple of requests, not a thousand.**

`readOpenMatches` reads a page of matches in ONE `readContracts` multicall and
derives `expired` from a single `getBlockNumber` against the contract's own
`matchExpiryBlocks`, instead of one round trip per index plus one more for the
expiry flag. Creating an open match costs only gas, so the active set is cheap
for anyone to inflate, and every lobby tab was a thousand-request poller against
a paid RPC endpoint every eight seconds for as long as the spam sat there. The
fallback poll also skips a tick while one is still in flight.

**Registrar tooling reads the contract's money terms instead of asserting them.**

New `readWagerFeeTerms(rpcUrl, wagerAddress)` (exported from
`@xayaarcade/sdk/e2e`) answers `{ burnBps, feeBps, allowedBets }`. The GSP
prices every payment-queue entry from the registry row while the contract
computes the pot from its own immutable split, so a row that disagrees mints
amounts no snapshot can carry and every paid create at that stake reverts from
then on. `submissions`' registrar and `scripts/register-rules.ts` take those
values from the deployment named by the new OPTIONAL `WAGER_ADDRESS` env var
and refuse before sending when a registry row already disagrees. Left unset,
both keep registering the plane defaults (500/500 and the beta ladder,
`PLANE_DEFAULT_TERMS`) exactly as before, and warn once that the check was
skipped.

## 0.15.5: 2026-08-24

**The result stays on screen until the player leaves it.**

A free channel's close recap used to vanish on its own: the moment the close
was noticed on-chain, ChannelGame navigated back to the lobby, which put the
You Win / You Lose screen up for exactly the close-detection latency, often
under a second: too briefly to read.
Paid channels never had this problem, because their recap carries binding money
disclosures and has always held until the player presses its own Back to Lobby
button.

One contract now, paid or free: the recap holds, the button leaves. Nothing
else about close handling moved: the close is still detected by
seen-open-then-gone (a dispute-timeout close never sets the board's `finished`
flag, so nothing may gate on it), `clearActiveGame()` still runs the moment the
close lands so a reload never resumes a dead channel, and the neutral wording
for an undecided close is untouched. The free-channel recap's "Returning to
lobby…" line (a promise the code no longer makes) now reads "Match settled."
like the paid one.

Not breaking for games: ChannelGame's props and every exported surface are
unchanged. A game that renders the SDK's screens simply keeps its result on
screen; a custom shell that relied on the free-channel auto-navigation (none of
the five game repos did: they all render ChannelGame) would now leave through
the recap button like everything else.

## 0.15.4: 2026-08-23

**A lobby stops asking the chain what it can simply be told.**

A wager lobby has been reading the open matches off the contract every eight
seconds, in every tab it was open in, for as long as it was on screen. Ten
people looking at the same lobby ran the same read ten times over; a hundred ran
it a hundred. Nothing in that answer is per-player -- it is the same list for
everybody -- so the relay now runs the read once for everyone and pushes the
result to the tabs that ask for it, and a tab being pushed to runs no timer at
all.

That is the whole of the saving. Where a tab used to make a handful of chain
calls every eight seconds, forever, it now makes none, and the relay makes that
handful once however many tabs are watching. The number of people in a lobby
stops being the number the chain endpoint is asked to carry.

The poll is still here, and still exactly what it was, for the relays that do
not push. An older deployment has never heard of the dialect and sends no wager
frame; the client sees that it is on its own and reads the contract on its old
cadence, unchanged. The same thing happens the moment a pushing relay reports
its own chain reads failing, or the socket drops: the lobby goes back to reading
for itself, starting immediately rather than waiting out an interval, and stands
down again when the pushes return.

Whichever way the matches arrive, it is the same lobby. A pushed document and a
contract read produce matches identical field by field, go through the same
comparison, and hand the screen the same references -- so a lobby that has not
moved still costs nothing to redraw, and a match that appears, fills, expires or
changes hands still lands the instant it is known. A document the client cannot
read in full is dropped in silence and the lobby keeps what it already had.

There is nothing to change in a game. `useArcadeWager()` and `useGspPolling()`
return exactly what they returned before. One function is newly exported for
anyone decoding a relay document outside the hook: `wagerDocMatchesFor(doc,
gameType)`, which turns one pushed document into the same open-match list the
contract read produces, or null if the document is malformed.

## 0.15.3: 2026-08-23

**A parked tab stops being sent the whole world every two seconds.**

Until now the relay sent every connected tab the complete game state on every
block -- several kilobytes, about every two seconds, whether or not a single
thing in it had changed. 0.15.1 and 0.15.2 taught a tab to ignore that cheaply;
this release stops it being sent at all. A client now says, as it subscribes,
that it can take a short block tick instead, and a relay that speaks them
answers a block on which nothing but the block header moved with roughly a
hundred bytes: the new height and block hash. On a tab left open all day that
is hundreds of megabytes of traffic that simply no longer happens -- which
matters most on a phone.

A tick moves the chain tip and the is-the-chain-still-moving check, and nothing
else, so a countdown or a block readout stays live while the rest of the screen
sleeps. Anything that genuinely changed -- a match appearing, filling, expiring
or paying out, the node falling behind or catching back up -- still arrives as
the full state it always did, the moment it happens.

There is nothing to change in a game. Against an older relay that has never
heard of block ticks the extra word in the subscribe message is ignored, full
states keep arriving on every block, and they are handled exactly as before: a
game vendoring this release works against either relay.

## 0.15.2: 2026-08-22

**The last of the work an untouched tab was still doing.**

0.15.1 stopped a lobby redrawing itself between blocks. Two smaller clocks were
still running underneath it. The wager lobby re-reads the open matches from the
contract every few seconds, and the balance readout re-reads POL and WCHI every
fifteen; both handed the screen a brand-new answer each pass, so both redrew
everything even when the answer was word for word the one already shown. Each
now compares what came back against what is on screen, field by field, and says
nothing when they match. A match that genuinely appears, fills, expires or
changes hands still lands the instant it is read, exactly as before.

The fifteen-second balance refresh also stops flipping the hook's `loading`
flag: a spinner that blinks on its own four times a minute was the same idle
work in another form. A read someone actually asked for -- the first one, a
wallet change, an explicit `refetch()` -- still reports loading exactly as it
did.

A tab parked on a lobby, with a wallet connected, now does nothing at all until
something actually happens.

Also: the chain tip a page starts from is now the same value the server rendered
rather than an identical-looking copy, which saved every component that reads it
one wasted redraw as the page came up.

Addendum to 0.15.1's breaking note: that release also
removed the `height` field from the `WagerGspInputs` object a game's lobby
passes into `useArcadeWager()`. Nothing ever read it, so the only effect is that
a lobby still supplying it will not compile until the field is dropped.

## 0.15.1: 2026-08-19

**A lobby left open now does nothing between blocks.**

The game state arrives from the relay in full on every block, about every two
seconds, and until now the whole screen was rebuilt each time: even when the
state that came back was identical to the one already on it. A tab left sitting
on a lobby therefore worked continuously for as long as it was open, and the
memory it held grew with it.

Two changes end that. An arriving state that matches the last one is recognised
as such and reuses what was already parsed, so the screen has nothing to redraw.
And the block height and hash, the two things that genuinely do change every
block, moved out of the polling hook into a small store that components read
only if they need it: the live game screen, and the countdown on a wagered
match still waiting to fill. Everything else now sleeps until something real
happens.

For a game embedding the SDK: `useGspPolling()` no longer returns `height` or
`blockHash`. Read them from the new `useGspBlock()` instead, in the component
that displays them rather than at the top of a screen: that is what keeps the
re-render local. **BREAKING** for anyone destructuring either value off
`useGspPolling()`; nothing else in the return changed.

## 0.15.0: 2026-08-18

**The agreed-match banner now sends the agreed transaction itself, and an
agreement can only ever be spent once.**

Two players agree a match in the arcade's own lobby and land in the game with it
already set up. Until now the game's lobby met them with one more button: create
the agreed game, join the agreed game, stake the agreed amount, and pressing it
opened the wallet. That button was collecting a consent the wallet prompt was
about to collect anyway, so it is gone: the banner puts the transaction in front
of the wallet as soon as the agreement can be acted on, and **the prompt is the
consent**. Nothing is ever sent without one.

Per role:

  * a free creator's table is opened at the agreed seat count, with no press;
  * a joiner's join goes out the moment the agreed peer's table appears (the
    watch is unchanged (that peer, those seats, that stake), only the press is
    gone;
  * a paid creator is asked to approve WCHI first when their allowance is short,
    and to stake immediately after) each its own wallet prompt, and neither
    submitted until the wager module's own reads (allowance, and the pooled-queue
    snapshot for the agreed stake and seat count) have landed;
  * a paid joiner stakes into the agreed peer's match, never a stranger's.

While a prompt is up the banner reads *Waiting for your wallet…* for a creator
and *Table found: waiting for your wallet…* for a joiner. Every other state it
can reach says what is actually true instead: nothing to send yet (*Getting
ready: nothing has been sent yet.*, or for a paid creator the agreed stake and
a pointer at the stake control), or a request an earlier page load already made
and this one cannot know the end of (*Your wallet was already asked for this.*,
with a `Try again`). The in-flight line is never a stand-in for "no idea".

**At most one automatic prompt per agreement per step**, latched in localStorage
rather than in memory: the agreement travels in the page's own URL, so that URL
is a replayable token for an automatic transaction, and neither a reload, nor
reopening the link from history, nor middle-clicking it into a second tab may
produce a second prompt: a second table for a free match, a second escrowed
stake for a paid one. A prompt the player rejects, or a send that fails, is never
answered with another prompt: the banner says nothing was sent, hands over a
`Try again` button, and the retry is a press from then on. A failure is only ever
this banner's own: `approve()`, `create()` and `join()` on `useArcadeWager` now
resolve the tx hash they submitted (or null when nothing was), so a caller can
tell its own write's outcome from anything else that lands on the module's shared
error list meanwhile. **Consumers of `ArcadeWagerState` that annotate those three
as `Promise<void>` need the type widened; call sites that ignore the result are
unaffected.**

**FIX: a played agreement never arms again.** The shell keeps handing the same
agreement to the page for as long as the player stays on it, so once a match had
been played to the end the banner re-derived a live *create the agreed game* offer
from it: one press away from opening a table for a match that was already over.
An agreement is now CONSUMED the moment its own transaction confirms (the create
for the player who agreed to host, the join for the player who agreed to join);
the banner then arms nothing at all, page reloads included. The mark is per
agreement (keyed by when it was struck and who with) so the next agreement the
shell sends is unaffected.

**A spent agreement never talks a player out of a game they are still in.** It
reads *Match played: find your next game in the Lobby.* only when nothing of
theirs is standing. While their own table is open, their stake is escrowed, or
their match is live, the banner says THAT instead (*Matched with p/… (waiting
for them to join your open game.* / *… your staked match.* for the half that
agreed to host, *Your game is open) waiting for players.* for a table of ours
this agreement is not about, *You're seated (waiting for the table to fill.*,
*Your match is in progress) resume it below.*), because leaving is the losing
move in every one of those states, and at a stake it loses the stake to the
timeout as well. When this build could never have honoured the agreement, that
explanation keeps its place as a second line underneath.

Deliberately unchanged: the 90-second staleness hint on a joiner's wait, the guard
that arms nothing for a seat count this game cannot host or a stake this build
cannot take, the paid registry clamp, the manual create card (still the retry
route, still folded behind its disclosure inside the shell) and the whole
standalone lobby. No protocol change either: the bridge wire format and both
twinned modules are untouched, so this needs no shell release to take effect:
but every game bundle carries its own copy of the lobby, so re-vendor and rebuild
to pick it up.

## 0.14.2: 2026-08-17

**Embedded, the lobby's "Create a game" card now sits behind a disclosure.**
Inside the arcade shell a player's normal route to a game is the shell's own
lobby, where two players agree a match and neither side pays for anything until
both accept. The game lobby's create card is the opposite: pressing it opens a
table on-chain immediately, and it read as the obvious first step. Embedded it
is now folded behind a toggle reading *Advanced: open a table on-chain now*,
with a sentence explaining what pressing it costs, collapsed on every mount and
never remembered.

Standalone builds are **unchanged**: there is no shell lobby to route through,
so the create card stays the lobby's primary control, unfolded, and no
disclosure element exists in the tree at all.

The fold is presentation only. The same card with the same handlers is what
unfolds (stake tiers and the seat picker included: they belong to the card and
demote with it), opening or closing it signs nothing, and the agreed-match
banner, the open-games join list and the active-game resume/leave affordances
render outside it, unchanged in both modes.

**The fold never applies to a card the banner has armed.** A paid creator who
agreed a stake is told *stake below to start*, and the button that does it lives
in this card: for that state the card renders unfolded with no toggle at all:
the agreed route is not an advanced one. Every other embedded state folds (the
free agreed creator presses a button in the banner itself; a paid joiner's route
is the banner's join, and this card would open a competing match; an agreement
this build cannot honour arms nothing and points at the lobby as a whole, whose
open-games list is already unfolded).

**New: a staleness line on the joiner's wait.** After 90 seconds of continuously
waiting for the agreed peer to create the game, the banner adds *Still waiting:
they may have moved on. You can agree another match in the Lobby.* It is a line
of text: nothing is cancelled, nothing is unarmed, the agreement stays live and
the join button still arms the moment the peer's game appears. The clock belongs
to that one wait, so it restarts if the wait does, including when the shell
hands the game a *different* agreement while the waiting line stays on screen.
Creator-side waits get nothing: they are waiting on a table they already opened.

No protocol change: the bridge wire format and both twinned modules are
untouched, so this needs no shell release to take effect.

## 0.14.1: 2026-08-12

**Test Wallet 3 and Test Wallet 4 changed addresses.** A fork-testing deployment
holds real signing keys for these two identities, and the chain-side accounts
behind their previous addresses are retired. `ALL_DEV_WALLETS`
(`dev-wallet.ts`) now reads:

    Test Wallet 3: 0x4D62Bd97aB0a3351f23B51Ab8754eaF6f6C3f7DB
    Test Wallet 4: 0x1b2F24dCaddd20ff513417Da6C3E8Fe2354c303B

Test Wallet 1 and 2 are unchanged. This roster is still address-only: no key
enters the SDK or any game bundle, and standalone games drive wallet 3/4
transactions via the fork's account impersonation. The signing keys for these
two identities are supplied only to the arcade shell's own fork-testing build,
never to a game.

**Why this needs a bump:** every game bundle bakes `ALL_DEV_WALLETS` at build
time. A bundle still carrying the previous addresses would offer to connect as
EOAs that no longer own anything on the fork. Re-vendor to pick this up before
rebuilding any bundle that uses wallet 3 or 4.

## 0.14.0: 2026-08-10

**Two players can now agree a game in the arcade's own lobby and land in yours
with it already set up.** The shell sends one new message after `arcade:caps`:

    shell -> game : { type:'arcade:matchmake', role, seats, tier, peerName, ts }

`role` is `'create'` or `'join'`, which half of the agreement this player took;
`tier` is `'free'` or the agreed stake in WCHI base units; `seats` is 2..8;
`peerName` is the opponent's namespace-stripped Xaya name. Both protocol twins
carry it and the parser rejects a bad role, a seat count outside 2..8, and a
`'0'` tier (free is spelled `free`, never a zero stake).

**New: `ArcadeBridgeValue.matchmake`**: the agreement for this session, or
`null` when the player did not arrive through the lobby (and always `null`
standalone). `routeShellMessage` gains an optional `onMatchmake`, absent means
drop in silence.

**New: ChannelLobby's agreed-match banner.** The first card in the lobby when an
agreement arrived: one button pre-filled with what the two players settled on:
`Create the agreed 3-player game`, or `Join p/bob's game` once the peer's game
actually appears. A paid agreement arms the existing stake controls (tier and
seat count) instead, once, and says so.

The banner **arms; it never acts.** It fires no create, no join and no stake
until the player presses it; the join half is a watch against the peer's own
open game at the agreed seats and stake, so a near-miss arms nothing; and every
ordinary lobby card renders unchanged underneath it, so ignoring the banner
costs a player nothing. The game holds no wallet either way: the shell is
still the only signer.

Additive throughout: an older game drops the message in silence, and a game on
this version against a shell that never sends it renders exactly today's lobby.

## 0.13.0: 2026-08-07

**A lobby could be built that took your stake and never opened a game, and the
client would have signed it.** ArcadeWager validates a match's escrowed queue
snapshot for STRUCTURE only: it has no view of the GSP's queue, so it cannot
tell the front of that queue from a group further back, and `_startMatch` pays
whichever group of the snapshot still has an unpaid member. A creator who
escrowed only their OWN queued claim therefore got a lobby that paid them the
pot the moment it filled, while the GSP refused to open the channel because the
front it expected was never settled. The joiner's stake was gone, no game was
played, and both refund paths require `m.active`, which the fill had already
cleared.

The joiner's gate could not catch it. It asked whether the stored queue was an
order-preserving SUBSEQUENCE of the live one, and a lone later group passes that
trivially. `firstGroupIsLiveFront` replaces it at both first-party signing sites:
derive the group the contract would actually pay out of the stored snapshot,
derive the live front from the GSP slice, and require them to be the same
entries in the same order. Paid state is read for the stored entries as well as
the live ones, because a group settled elsewhere is dropped from the GSP's slice
while still sitting in the snapshot: reading it as unpaid would refuse an
honest join.

The lobby no longer offers such a row at all: `WagerPanel` judges each joinable
row once its combo's queue is known and disables Join with the reason inline, so
the lobby is inert in the UI rather than only erroring at the last step.

Nothing on-chain can catch this, so there is no contract change to wait for.
**Upgrade if you take wagers.**

**BREAKING (adapters that build an `ArcadeWagerState` by hand):**
`ArcadeWagerState` gains `queueSlice(bet, numPlayers)`, which returns the live
pooled-queue slice for ANY combo. It is required because `front` is scoped to
the one combo in view while every joinable row belongs to its own. Games that
consume the hook normally are unaffected; only a test double or a hand-built
state object needs the extra member.

**New: the beta payout disclosure.** `BetaPayoutNotice` renders above the stake
button and beside the joinable list: never in the end-of-match recap, where the
money is already committed. It says that winnings are paid out by the next match
at the same stake and seat count, that the arcade may be reset, and that
winnings still queued would not survive it. It is off unless a deployment's
runtime config sets `wagerBeta: true`, so a real launch turns it off with one
JSON edit per plane rather than a rebuild of every game bundle. Only a literal
`true` enables it.

## 0.12.1: 2026-08-01

**Player-facing money copy was wrong on both counts, and this fixes it.** The
end-of-match recap (`ChannelGame`'s queue-deferred explainer) is what a winner
reads at the moment they are told what they won, and it said:

> Payment is queued and pays out when the next 10-WCHI 2-player match **of this
> game** starts. If this is **the first** paid match at this stake and player
> count, its pot instead pays a one-time bootstrap fee to the operator…

Both halves described the pre-pooling world. It now says the payout comes from
the next match at that stake and seat count **in any game on the arcade**,
because the queue is pooled and the paying match can belong to any of them; and
that **one of the first three** paid matches at a cold combo pays the operator,
because a combo is seeded three groups deep, not one.

That second clause is the one to care about: understating it as "the first" told
the second and third players at a cold combo that they were getting paid, when
their pot goes to the operator as a one-time bootstrap fee. If you render your
own recap rather than the SDK's, fix the same two things in it.

Nothing else changed: no API, no encoding, no behaviour. `0.12.0` and `0.12.1`
are wire-compatible with each other and with the same pooled ArcadeWager.

**Why this is 0.12.1 and not an amended 0.12.0:** the copy shipped inside
`0.12.0`'s tarball, so correcting it in place would have left two different
byte-sets answering to one version number, and `sdk-freshness.sh` compares
version strings. Bump to pick this up.

## 0.12.0: 2026-08-01

The payment queue is now POOLED by stake tier: 10 WCHI is 10 WCHI across every
game on the arcade, so one FIFO serves a `(tier, seats)` combo no matter which
game a lobby belongs to. That collapses a game level out of every queue shape
the SDK carries, and it is **BREAKING against a pre-pooling ArcadeWager**: the
signatures below changed, and the encodings they produce do not verify against
a contract that still hashes a game into its payment key. Vendor this version
only alongside a pooled-queue deployment; re-vendoring it against an older
contract makes every paid create and join revert.

**BREAKING: three exports changed shape:**

- **`paymentKeyOf(bet, numPlayers, matchId, payee)`**: the leading
  `gameType` argument is gone, and with it the `keccak256(bytes(gameType))`
  member of the encoded tuple. A queue row must be identifiable from the row
  alone, with no idea which game produced it; a key that still varied by game
  would let one pooled queue row be paid once per game. Callers pass four
  arguments now, and the golden vectors that pin the encoding moved with it.
- **`readPaidSet(address, bet, numPlayers, entries)`**: same removal, for the
  same reason: `(bet, numPlayers)` alone names the queue those rows came from.
- **`PaymentQueuesV2`**: now `tier → numPlayers → combo`, exactly two map
  levels where there were three. `parsePaymentQueuesV2` reads the GSP's
  `paymentqueues` export in that shape. Any caller that indexed
  `queues[gameType][tier][n]` must drop the first index; left as-is it reads a
  combo where it wants a map and silently finds nothing, which presents as a
  permanently empty queue rather than as an error.

**New: multi-group snapshots.** A paid create or refresh no longer commits to
just the front group. `effectiveSnapshot(entries, comboLength, isPaid, depth)`
returns the first `depth` groups' unpaid members in queue order, skipping any
group already fully paid, and `useArcadeWager` submits that. The contract walks
the stored snapshot at START time and pays the first group that still has an
unpaid member, so several lobbies can open against one queue state and still
settle successive fronts in strict order, with a single-group snapshot every
lobby but the first would find its one group already paid and revert. The hook
keeps the snapshot internal; `front` still reports the effective FRONT GROUP,
which is what the UI shows and what a joiner is checked against.
`effectiveSnapshot` fails closed on a truncated slice (`entries.length <
comboLength`) exactly like `effectiveFrontGroup`, and neither mirrors the GSP's
row cap as a constant: compare the two lengths, because the cap is the GSP's
to move.

**New: a genuinely empty queue is refused gracefully.** `create()` and
`refreshFront()` now check the snapshot is non-empty before they build a
transaction and push `no payout queue front at this stake yet` when it is not.
The contract reverts a zero-length snapshot regardless; refusing client-side
costs the player no wallet prompt and no gas, and uses the same wording the
Arcade shell uses for the identical case on its brokered path, so a player sees
one message whichever way they came in. `frontBlocked` remains the *truncation*
signal only: an empty front is a known-empty queue, not an unknowable one, and
must not light the truncation warning.

**New revert copy.** `formatWagerError` maps two more contract strings:
`invalid queue snapshot size` to the same `no payout queue front at this stake
yet` wording as the client-side refusal, and the new `queue snapshot exhausted`
: every group in a lobby's stored snapshot was already paid by the time it
filled: to a prompt to refresh the queue and try again.

**Also in the GSP client.** `PaymentQueueEntry` describes rows of the flat
cross-combo `paymentqueue` export, which now spell out `numPlayers` and
`amount` per row since there are no longer map keys to carry them. There is no
parser for the flat list (every wager path reads the nested export) and no
game field anywhere in either.

## 0.11.1: 2026-07-31

A security fix in the in-browser judge. No API change; nothing a conforming
blob does behaves differently, so a game only needs to re-vendor and rebuild.

- **A guest-chosen buffer offset is now required to be strictly positive.**
  `arcade_alloc` returning zero has always been the allocation-failure
  sentinel, but a NEGATIVE return was passed straight through to
  `new Uint8Array(memory.buffer, ptr, len)`, which throws a `RangeError` out of
  a boundary every caller treats as null-returning. The input buffer and the
  output buffer are separate allocations with separate guards, so both are
  checked. The wasmtime host on the GSP side applies the identical rule, and
  the same fix landed there in the same change: the two judges have to agree
  on what they refuse, or they disagree about the game.
- **An export whose result type is wrong is now rejected instead of being read
  as a length.** A wasm function declared with no result hands JavaScript
  `undefined`, and `undefined < 0` and `undefined > cap` are BOTH false, so the
  previous range-only test admitted it, and `new Uint8Array(buf, ptr,
  undefined)` means "to the end of the buffer". A blob that passes both ABI
  gates (neither checks signatures) could therefore turn every move into a
  state consisting of the whole of its own linear memory, which the SDK signs
  and broadcasts to every participant. The length is now type-checked before it
  is range-checked.

Neither is reachable through the three shipped games' blobs, which are honest
allocators; this closes the path a submitted blob could take.

## 0.11.0: 2026-07-30

The full frame on a phone for a game that has no on-screen controls, and the
coarse-pointer test a game needs to build its own touch UI. Both additive:
every existing game and every fine pointer behaves exactly as in 0.10.0.

New in the main entry:

- **`GamePresentation.fullFrameOnTouch?`**: set it and the bridge skips the
  `arcade:presentation` post on a coarse-pointer device, so an embedding
  shell leaves the game the whole frame instead of letterboxing to
  `aspectRatio`. This is what 0.10.0 gave a game with `touchControls`, but
  0.10.0 gave it ONLY through that field, so a tap-native game could not have
  it without also mounting a d-pad it does not want. The cost it removes is
  not just dead gutter: the letterbox also shrinks every tap target on the
  board inside it: measured on a 390×844 phone, a `1.6`/`360×420` game's
  cells went from 16.8 px to 36.9 px on the full frame. Absent: the default
: means the declared shape is honoured everywhere, as before. A game
  declaring `touchControls` already gets the skip and need not set this too.
- **`useCoarsePointer()`**: the hook the SDK's own touch layer uses: `true`
  when the device's primary pointer is coarse. Exported so a game can gate
  its own touch-only affordances (a tap-to-confirm bar, a fatter hit box)
  without re-deriving it, and the naive re-derivation is wrong, because the
  `matchMedia` read must happen in an effect and never in render scope: under
  the React Compiler a render-scope read is memoized and frozen at `false`, a
  bug invisible to jsdom tests and only observable in the built bundle. It
  returns `false` on the server and on the first client render, flipping
  after mount. The `TouchControls` component it lives beside stays internal.

## 0.10.0: 2026-07-30

On-screen touch controls, SDK-owned and auto-mounted: a game declares an
optional `touchControls` spec on its adapter, and coarse-pointer (touch)
devices get a d-pad and action buttons that synthesize the same window
KeyboardEvents the game's keyboard hook already consumes. Additive: no
breaking API changes, and zero change to any game's input logic, held-key
model or submit timing. Desktop behaviour is untouched.

New in the main entry:

- **`TouchControlsSpec`**: the declared shape of the on-screen controls: an
  optional 4-way `dpad` (values are `KeyboardEvent.key` strings) and optional
  `buttons` (`{ key, label }`; the key is held while the button is pressed).
- **`GameAdapter.touchControls?`**: declare it and `ChannelGame` mounts the
  overlay by itself on coarse-pointer devices while input is live (channel
  ready, an opponent present, match not over). Absent (the default) means
  no on-screen controls, exactly as before (e.g. tap-native games), and an
  EMPTY spec (no dpad, no buttons) is treated as absent everywhere. The
  `TouchControls` component itself is internal: there is nothing to import
  or render. `hasTouchControls(spec)` is exported as the shared predicate.

Behaviour while the controls are mounted:

- **The pad is owned by one pointer at a time** and a finger SLIDING between
  zones re-steers without lifting (`keyup` of the previous direction, then
  `keydown` of the next, synchronously). A ~20% radial dead zone and angular
  hysteresis keep a thumb resting near a 45° boundary from flapping
  directions. Buttons each track their own pointer, so pad + button work
  simultaneously.
- **No stuck input, ever**: pointerup, pointercancel, lostpointercapture,
  window blur, tab-hide and unmount all release every synthesized key: a
  held direction surviving a screen lock would walk the player into fire in
  a wagered match.
- **Touch events from the controls never reach window**, so a game's own
  window-level swipe listeners cannot read a pad gesture as a swipe.
- `ChannelGame` hides the keyboard `controlsHint` line (the pad sits in its
  corner and key names mean nothing on a phone) and sets `touch-action: none`
  on its root so a double-tap next to a control cannot viewport-zoom the
  page mid-match.
- **The bridge skips posting `arcade:presentation`** when the primary pointer
  is coarse and the adapter declares `touchControls`: an embedding shell then
  leaves the game the full frame instead of letterboxing to the board's
  aspect ratio, the board centers itself, and the controls land in the game's
  own gutter rather than on the board.

## 0.9.0: 2026-07-29

Additive exports, two behaviour fixes on the dispute/settlement path, and
this file. No breaking API changes, but read the MoveBroker note.

New in `/core`:

- **`PlaceholderBoardState`**: the "no game yet" state for zero-length
  encoded bytes. Return it from `parseState` when
  `encodedState.length === 0` and delete your local copy: every game repo
  carried its own near-identical `class PlaceholderState` (identical but for
  xayaman's extra `ejectedMask()`, which the SDK class includes), and 0.7.0's
  required-method additions broke all of them at once over a class whose
  correct implementation is a constant.
- **`buildChannelMetadata(participants, reinit)`**: replaces the hand-built
  two-schema `create(ChannelMetadataSchema, …)` dance (seventeen call sites
  across the game repos' harnesses/tests and the platform's own at the time
  of this release). Wire-identical to what it replaces; seat order is
  participant order. Also re-exported from `/e2e` for harnesses.

New in the main entry:

- **`ImmersiveOnChannel`**: the render-nothing component that requests
  chrome-hide while a channel is live. All three game repos shipped it
  byte-identical (one md5); delete your copy and import it.

Fixed:

- **Dispute resolutions no longer stack while one is being signed.**
  `tryResolveDispute` re-enters on every on-chain push, but the
  duplicate-send guard was only set after the send resolved, so during a
  multi-second wallet prompt each new block fired another resolution
  (stacked prompts; extra txs rejected as not-newer, or nonce errors surfaced
  as spurious money errors mid-dispute-defence). An in-flight latch now gates
  the auto path; the explicit `fileDispute()` sets the latch but is not
  blocked by it, so the user action stays the escape hatch.
- **A draw is closed by the lowest LIVE seat, not hardwired seat 0.** With
  seat 0 ejected before the survivors drew, no client ever submitted the
  closing resolution and the pot stayed locked in the open channel.
- **`MoveBroker.sendMove` now throws on a missing/empty `signerName`**
  instead of posting an unbound request the shell refuses, which, with the
  default no-timeout wait, was a silent forever-hang. (The shell also now
  answers an error `move-result` to an id-carrying unbound request instead
  of dropping it, so pre-0.8.0 bundles fail loudly too.)

Hygiene, enforced by new gates:

- `tests/core-isomorphic.test.ts` now actually exists and walks `/core`'s
  real import graph (an allowlist of isomorphic deps): the gate `core.ts`
  had described was never written until now.
- Tests are typechecked (`tsc -p tsconfig.tests.json` in `npm run
  typecheck`); the doubles that had drifted onto the pre-0.7.0 interface are
  fixed.
- `CHANGELOG.md`'s head entry must match `package.json`'s version (gate).
- The shell/SDK `protocol.ts` twins must be byte-identical past their header
  comments (gate; they had already drifted).
- `channelIdHex()` is used everywhere a channel id is formatted in `src`
  (twelve open-coded pads replaced, including in signed messages).

## 0.8.0: 2026-07-29

**BREAKING** for arcade-embedded (shell-brokered) play. Standalone games are
unaffected.

- `signerName` on `arcade:move-request` is now **REQUIRED**. The shell refuses
  to sign a move that does not name the channel participant it is for, so a
  mid-channel identity switch is detected instead of silently signed over.
  `BrokeredWriter` already passes it from `args[1]` of `XayaAccounts.move`;
  if you drive `MoveBroker.sendMove` yourself, pass the participant name.
  The shell DROPS an unbound request, and a dropped postMessage never
  settles the promise, so `BrokeredWriter` throws at the call site rather
  than let you hang.

## 0.7.0: 2026-07-28

Version-number release only: it declares the changes cut as 0.6.0 the same
day to be **BREAKING** (they are). No consumer ever vendored 0.6.0: treat
0.6.0 + 0.7.0 as one breaking release with the content below.

## 0.6.0: 2026-07-28

**BREAKING** for every game. The SDK absorbed the code all game repos were
copying, and deleted the shapes that forced the copying.

- NEW entry **`@xayaarcade/sdk/core`**: isomorphic (browser bundle, Next
  server, bare `tsx`): protobuf wire types, base64/sha256, channel value
  types and sentinels, `BoardRules`/`ParsedBoardState`/`OpenChannel`,
  `ChannelConfig`, the dispute/resolution move builders, `PackedJudge`.
  Retires the per-repo `#sdk-proto` twin-file pattern and local
  base64/sha256 copies. `tests/core-isomorphic.test.ts` walks the entry's
  real import graph, so an accidental browser/node dependency fails a gate.
- `ParsedBoardState`: **`isFinished()` and `winner()` are now required.**
  The settlement path reads them typed; before, it reached for
  `toJson().winner`, an untyped read of a game-specific display object.
  `winner()` is the ABI's raw convention (−1 undecided, −2 draw, else seat).
- `ParsedBoardState.moveCount()` **DELETED**: `turnCount()` is the one
  progress counter; the ABI has only ever had one.
- `OpenChannel` is down to ONE method, `maybeAutoMove(state)`. The
  dispute/resolution move bodies are the HOST's format, not a game's, and
  moved to `/core`'s `disputeMoveObject` / `resolutionMoveObject`.
- `ChannelConfig` is a validating value: `ChannelConfig.build` throws on
  out-of-range input rather than masking it.
- **DELETED**: `DEV_WALLETS`, the v1 `paymentQueues` read,
  `loadArcadeRuntimeConfig` (superseded by the 0.5.3 runtime-config gate).

## 0.5.4: 2026-07-28

- `WsBroadcast` is reachable from Node (headless relay clients / e2e
  harnesses can drive the real relay). The `/e2e` entry gained a node-safety
  gate so browser-only code can never leak into it again.

## 0.5.3: 2026-07-27

- Hosted bundles fail closed and honest on every plane: the runtime-config
  gate refuses to boot a bundle whose configuration does not match the plane
  it is served on (no more silent mainnet leakage), and the `/g/<slug>`
  base is derived rather than trusted.
- Two-seat dispute timeouts are decided by the blob, not hardcoded.

## 0.5.2: 2026-07-24

- Path-based serving: SDK fetches resolve against the baked `/g/<slug>`
  base path; fail-closed gate when the base is absent.

## 0.5.1: 2026-07-23

- Lobby layout fix (leaderboard/create-game card alignment).

## 0.5.0: 2026-07-23

- Shell screens rethemed to the arcade design language; copyright-guard
  self-test hardened; builder docs aligned with shipped behaviour.

## 0.4.9: 2026-07-22

- Hot-path channel/relay debug logs gated behind the debug flag; platform
  and builder docs corrected against the code.

## 0.4.8: 2026-07-19

- Waiting banner gated on the stall grace, not the raw disconnect flag.

## 0.4.7: 2026-07-18

- The N>2 in-game leave is a hardened sequence: leave latch, on-clock wait,
  then the timeout dispute; resilient to throws, escaped moves and pending
  disputes.

## 0.4.6: 2026-07-18

- Ejected-seat support: the rules blob's optional `arcade_ejected_mask` is
  exposed through judge handles and parsed states
  (`ParsedBoardState.ejectedMask?()`); state-proof signatures are required
  and pruned over LIVE seats only, mirroring the host's required-signer
  bound; a left channel demotes to a settling notice and its dead seat is
  never resumed.

## 0.4.5: 2026-07-18

- Wagered starts auto-enter the board; lobby un-letterboxed and two-column.

## 0.4.4: 2026-07-18

- The >2-seat forfeit routes through the timeout dispute instead of the
  2-player declare-loss.

## 0.4.3: 2026-07-18

- In-game waiting/dispute status is N-seat aware.

## 0.4.2: 2026-07-16

- `frontBlocked` clears once a truncated payment queue recovers.

## 0.4.1: 2026-07-16

- Approval waits for the mined receipt before clearing `needsApproval`;
  settled paid matches no longer claim an automatic lobby return.

## 0.4.0: 2026-07-16

- Wagering: lobby + in-game money UX, `useArcadeWager`, payment-queue v2
  surface with a height-staleness signal, additive wager/caps messages on
  the arcade bridge.

## 0.3.2: 2026-07-15

- Maintenance release; no functional changes.

## 0.3.1: 2026-07-15

- Runtime deployment-config overlay for arcade-hosted bundles; wagmiConfig
  built lazily so dev-wallet switching takes effect; theme token bounds.

## 0.3.0: 2026-07-14

- The presentation contract (chrome-hide, theme, letterbox): the SDK stops
  shipping a look and lets the shell own it.

## 0.2.1: 2026-07-14

- The `/e2e` subpath: everything a game's on-chain scenario runner needs.

## 0.2.0: 2026-07-14

- Shipped as real client modules with an honest dependency contract.

## 0.1.0: 2026-07-14

- Initial extraction of the shared client framework from the first game.
