# @xayaarcade/sdk

Client framework for games on the Xaya Arcade: channels, proofs, disputes, the
wasm judge, the shell bridge.

Version: whatever `package.json` carries, which is also the head entry of
[`CHANGELOG.md`](CHANGELOG.md): the two are held together by a test, so read
either. MIT · ESM-only (`"type": "module"`, side-effect-free).

The canonical builder documentation lives in the Arcade site's `/docs` section;
this README is the package-level reference for the SDK itself.

This is the package a game builder installs. It supplies everything a channel
game's frontend needs to run: the lobby, the channel manager, GSP polling, the
relay transport, the client-side wasm judge, the optional wagering module, the
presentation contract, and the bridge that lets a game run embedded inside the
Arcade shell. It names no concrete game: a game plugs in through a single
adapter, and nothing else in the package knows which game it is running.

## What is in the box

The SDK owns the whole client side of a channel game so the game author only
writes rules, a board renderer, and an input hook:

- **Channels**: creating, joining, aborting and settling on-chain game
  channels, plus the off-chain machinery that makes normal play free: signed
  state proofs, the move sender, dispute detection and the channel manager.
- **GSP state**: the relay pushes the host GSP's state to every tab (the full
  state when something changed; since 0.15.3 a ~100-byte block tick when only
  the tip moved) and `useGspPolling` drives the lobby and the live board off
  it, reading the GSP's `getcurrentstate` JSON-RPC directly only while the
  relay is down. Since 0.15.4 the wager lobby's open-match list arrives the
  same way, with the 8-second contract read kept as the fallback. `GspClient`
  also wraps the stock `getchannel` and the blob-serving `getblob` calls.
- **Relay transport**: the off-chain WebSocket broadcast that carries signed
  moves between players between on-chain settlements.
- **The wasm judge**: fetches a game's registered `rules.wasm` blob by its
  pinned hash, verifies it, and runs it in the browser through the same frozen
  `arcade_*` ABI the host GSP uses, so the client and the referee agree.
- **The wagering module**: optional per game; when an operator has registered a
  wager contract for the deployment, the lobby offers WCHI-staked matches, and
  when it has not, the same code is inert and free play renders identically.
- **The presentation contract**: how a game tells its host what shape it wants
  to be drawn at.
- **The arcade bridge**: the postMessage protocol an embedded game speaks with
  the Arcade shell, where the shell owns the wallet, the name and all signing.

## Upgrading

Each release is written up in [`CHANGELOG.md`](CHANGELOG.md). The notes below
are the ones that need a code change in a game repo.

### What changed in 0.19.0

Disputes and resolutions can use shared proof compression after the GSP's
coordinated activation. Standard Polygon senders discover support automatically;
old or unavailable GSPs keep legacy proofs. Game rules and signed state formats
do not change. See [proof transport](../docs/PROOF-COMPRESSION.md) for the format,
limits, custom-sender interface and rollout requirements.

### What changed in 0.17.0 and 0.18.0

- **BREAKING, 0.18.0: `controlsHint` is `string | { keyboard, touch }`.**
  Passing a string still renders exactly as before; the break is for code that
  READS the field as a string (`.length`, `.toContain`, a `string` parameter),
  which every game repo's own adapter test did. Narrow it where it is read.
- **BREAKING, 0.17.0: `useChannelManager`'s `moneyErrors` /
  `dismissMoneyError` are now `sendErrors` / `dismissSendError`**, and carry
  every failed on-chain send rather than a paid channel's only. Only an app
  that builds its own board screen on the hook is affected; games rendering
  `ChannelGame` need no edit. `presentation.squareBoard` is opt-in and inert
  otherwise.

### What changed in 0.16.0

Read [`CHANGELOG.md`](CHANGELOG.md) in full before this bump: it is the
largest breaking release since 0.8.0. The edits a game repo has to make:

- **A signing address must be an EIP-55 canonical address.** `isSigningAddrSafe`
  refuses anything else, so a game that hands the shell a lowercase address, or
  anything that is not an address at all, stops working. The SDK's own session
  keys already produce the canonical form; a game minting its own must too.
- **`SignatureVerifier.recoverSigner` returns `string | null`.** A game or
  harness with its own verifier must widen the return type, and must answer
  `null` (never a placeholder string) for a signature it cannot recover.
- **`buildSecurityHeaders`'s `connect-src` no longer grants bare `wss:`/`ws:`.**
  A standalone game served with a cross-origin relay, GSP or chain RPC must set
  `NEXT_PUBLIC_RELAY_URL` / `NEXT_PUBLIC_GSP_URL` / `NEXT_PUBLIC_POLYGON_RPC` at
  build time (or `NEXT_PUBLIC_RELAY_URLS`, comma separated, for a plane running
  several relays), or pass the origins as `{ connectOrigins: [...] }`. The
  `middleware.ts` call site itself is unchanged.
- **The wager client speaks ArcadeWager v2 only.** A build carrying the old
  client against the new contract address (or the reverse) reads the payment
  queue wrongly and must not be pointed at either. The registrar tooling gains
  an optional `WAGER_ADDRESS`: set it and the registry's money terms are read
  from that deployment and checked against the GSP's row; leave it and the
  plane defaults are registered unchecked, as before.

### What changed in 0.15.x

- **0.15.5: the close recap holds on every channel, free included, until the
  player presses Back to Lobby.** Paid channels always worked this way; a free
  channel's recap used to vanish the moment the close was noticed on-chain.
  Nothing exported changed, so a game rendering `ChannelGame` needs no edit: a
  custom shell that relied on the free-channel auto-return must leave through
  the recap button instead.
- **0.15.4: `wagerDocMatchesFor(doc, gameType)` is exported**, for decoding a
  relay-pushed wager document outside the hook.
- **BREAKING, 0.15.1: `useGspPolling()` no longer returns `height` or
  `blockHash`.** Read them from `useGspBlock()`, and call it in the component
  that actually displays the tip rather than at the top of a screen: the point
  of the move is that only that component re-renders per block. Anyone
  destructuring the two off `useGspPolling()` must change; nothing else in its
  return moved. `WagerGspInputs.height` is gone for the same reason, so a lobby
  still passing it will not compile.
- **0.15.0: `approve()`, `create()` and `join()` on `useArcadeWager` resolve
  the submitted transaction's hash** (`Promise<string | null>`; null when
  nothing was submitted). Failures are still reported on `errors` exactly as
  before. Call sites that ignore the result are unaffected; anything typing
  `ArcadeWagerState`'s three writes as `Promise<void>` must widen.

### What changed in 0.8.0: the shell's identity binding is mandatory

**`ArcadeMoveRequest.signerName` is REQUIRED**, and the shell drops a move request
without it. It binds a brokered move to the channel participant it must be signed
as, so the shell can refuse to sign under a different arcade identity if the player
switched mid-channel.

It was optional for back-compat, which made the check opt-in by the only party it
constrains: a game that simply never sent the field got no binding and no
complaint. The failure it guards is silent on both sides: the shell signs happily,
and the move lands on chain attributed to a name that is not a participant in that
channel. A defence you can decline by omission is not a defence.

For a game this is normally invisible: `BrokeredWriter` reads the binding from the
move's own `args[1]`. What changed is that it now **throws** when that argument is
missing or empty, rather than sending an unbound request: a dropped `postMessage`
has no error path, so the old behaviour would have surfaced as a promise that never
settles. **A game bundle built against an older SDK must be rebuilt.**

### What changed in 0.7.0: a new entry point, and a smaller `OpenChannel`

**`@xayaarcade/sdk/core` is new, and it is probably what your shared code should
import.** Code a game shares between its Next app and its `tsx`-run scenario
runner previously had no entry it could take a runtime VALUE from: the main entry
drags in connectkit (`ERR_PACKAGE_PATH_NOT_EXPORTED` under tsx) and `/e2e` imports
`node:crypto`/`node:fs`/`ethers`. Every game repo bridged that with a
`sdk-proto.ts`/`sdk-proto.node.ts` twin behind a package.json `#sdk-proto` imports
map (to reach one protobuf schema. `/core` is isomorphic (its built chunk graph
may reach `@bufbuild/protobuf` and `@noble/hashes` and nothing else, Node builtins
included) gated in CI), so those twins can be deleted.

**`OpenChannel` is one method: `maybeAutoMove`.** Three went to the platform,
none of which was ever game-specific:

- **`resolutionMove`/`disputeMove` are gone.** They built the HOST's move format,
  which `engine/gsp/logic.cpp` parses identically for every registered game type:
  all three game repos' implementations were byte-identical. `MoveSender` builds
  them itself now; if you need the raw bodies, `disputeMoveObject`/
  `resolutionMoveObject` are exported from `/core` and `/e2e`.
- **`maybeOnChainMove` is gone.** Every game returned `null` and nothing in the
  SDK ever called it. The seat that closes a finished channel is chosen by
  `ChannelManager` from the board's own winner.
- **`MoveSender`'s constructor lost its trailing `OpenChannel` argument.**

**`ParsedBoardState` requires `isFinished(): boolean` and `winner(): number`.**
Both are straight `arcade_*` reads your `PackedHandle` already exposes, so a
`BoardRules` wrapper usually just forwards two more scalars, but the placeholder
state you return for an empty board needs them too (`false` and
`WINNER_UNDECIDED`). The SDK could not see these before, so the path that submits
the resolution closing a funded channel read `toJson().winner`: an untyped key
off a game's DISPLAY object.

**Deleted with no replacement**, all confirmed to have had no caller: the
`DEV_WALLETS` constant (use `devWallets()`; the constant was frozen at module load
from the BAKED flag, so a hosted bundle got `[]` even when the served config
enabled dev wallets, and the connect screen fell through to a real wallet), the v1
`paymentQueues` GSP export (use `paymentQueuesV2`), and `loadArcadeRuntimeConfig`
(use `loadArcadeRuntimeConfigOutcome`, which distinguishes "nothing served" from
"served but broken").

> **`paymentQueuesV2` changed shape in 0.12.0.** Payment queues are now pooled
> per stake tier across every game, so it is two map levels: `tier →
> numPlayers → combo`, with no game level at all. Code written against the
> older three-level form indexes one map too deep and reads nothing, which looks
> like a permanently empty queue rather than an error.

**Also new:** `channelIdHex(id)` in `/core`: the 64-char on-chain form the GSP
matches literally, previously open-coded 26 times across four repos, and
`quietChannelLogs()` in `/e2e`, which drops the channel layer's per-move chatter.

### What changed in 0.6.0

- **`PackedJudge.initialState(participants, config)` takes a `ChannelConfig`,
  not loose bytes**: see [The channel config](#the-channel-config). The old
  parameter was named `cfg12`, hardcoding one game's 12-byte layout into the
  signature as if it were universal; it is not, and two games shipped a wrong
  cfg past it. Build the value with `ChannelConfig.build(seed, cfgSuffix)`.
- **`ParsedBoardState.moveCount()` is gone; use `turnCount()`.** The interface
  declared both while the `arcade_*` ABI has only ever had one progress counter,
  so every game implemented one as a passthrough to the other.
- **`WsBroadcastConfig.audience`** is a per-instance field (optional; the
  `NEXT_PUBLIC_RELAY_AUDIENCE` env var is still the fallback, now read at
  construction rather than at module load).

## Install

There is no registry publish: a game repo vendors a `file:` tarball built from
the platform repo. In practice a game does not run the two commands below by
hand: each game repo commits the tarball and drives the whole pack-and-vendor
flow through its own `scripts/vendor-sdk.sh`, which packs this workspace, copies
the `.tgz` and its sha256 sidecar into the game's `vendor/`, and records the
platform commit it came from.

```
npm ci && npm pack -w @xayaarcade/sdk   # in the platform repo; `prepack` builds sdk/dist, the .tgz lands in its root
```

The `npm ci` is part of the recipe, not a precaution. `prepack` runs `tsup`,
which the workspace resolves from the ROOT install rather than one of its own,
so a bare `npm pack -w @xayaarcade/sdk` in a checkout whose root dependencies
are missing dies at `sh: 1: tsup: not found` (exit 127) with no `dist/` built
and no `.tgz` written.

Copy the `.tgz` into the game repo's `vendor/` and depend on it by path, under
whatever filename `npm pack` actually wrote:

```json
"@xayaarcade/sdk": "file:vendor/xayaarcade-sdk-<version>.tgz"
```

The version in the filename must change on every repack a game repo vendors:
bump `sdk/package.json`'s `version` before packing. A same-version repack is the
worst failure shape available: `npm install`, and `npm ci` against a warm cache,
both keep the OLD content silently, while `npm ci` against a cold cache
hard-fails with `EINTEGRITY`. Bumping the version changes the filename, hence
the `file:` specifier, hence the lockfile entry, and both commands pick the new
content up immediately.

React 19 and the wallet stack are peer dependencies: a consuming app provides
them: `react` / `react-dom` `^19`, `wagmi` `^3`, `@wagmi/core` `^3`, `viem`
`^2`, `connectkit` `^1.9`, `@tanstack/react-query` `^5`. Runtime dependencies
the package brings itself are `ethers`, `@noble/hashes`, `@bufbuild/protobuf`
and `zustand`.

Four entry points:

| Import | For |
|---|---|
| `@xayaarcade/sdk` | The browser client framework: everything below. This is what a game frontend imports. |
| `@xayaarcade/sdk/core` | The ISOMORPHIC subset: safe in a browser bundle AND under a bare `npx tsx`. The protos, base64/SHA-256, the channel types and wire constants, `ChannelConfig`, `buildChannelMetadata`, the dispute/resolution move bodies, `PlaceholderBoardState` (the "no game yet" state every `parseState` returns for zero bytes), and `PackedJudge`. What a game's SHARED code (its `BoardRules`, its `OpenChannel`, its packed codec) should import. |
| `@xayaarcade/sdk/e2e` | Node-only test infrastructure a game repo builds its own scenario runners on: on-chain moves, the packed judge, the in-process `InMemoryBus`, and `WsBroadcast` for driving a real `xaya-relay` from a `node` harness. |
| `@xayaarcade/sdk/server` | Node-safe pieces for server-only consumers: `buildSecurityHeaders` (an app's `middleware.ts`, the bundle host) and `contentBuildId` (a game's `next.config.ts`). |

`buildSecurityHeaders(frameAncestors?, opts?)` always states a `frame-ancestors`
rule: the origin you name, or `'none'` (with `X-Frame-Options: DENY`) when you
name none. Its `connect-src` is an allow-list of ORIGINS and never of schemes: a
bare `wss:` would permit every socket destination on the internet, which is the
grant a compromised bundle would use to ship a session key somewhere quiet. If
your services are cross-origin, say so: pass `{ connectOrigins: [...] }`, or set
`NEXT_PUBLIC_RELAY_URL` / `NEXT_PUBLIC_GSP_URL` / `NEXT_PUBLIC_POLYGON_RPC` at
build time and their origins are picked up for you. A plane running several
relays names them all in `NEXT_PUBLIC_RELAY_URLS`, comma separated, and each
contributes two sources: the socket, and the `https://` origin of the timing
probe that chooses between them. `relayOrigins` (also on the `/server` subpath)
derives that pair for a serving layer resolving the list itself.

`contentBuildId(root?)` replaces Next's random build id with a hash of the
build's inputs, so the same source always exports the same static bundle:
`generateBuildId: async () => contentBuildId()` in `next.config.ts`. A Next root
without its own `package-lock.json` (a `web/` folder) hashes the nearest
ancestor's.

## Configure before you render

Before anything from the package renders, the app calls `configureApp` once with
its identity:

```ts
import { configureApp } from '@xayaarcade/sdk';

configureApp({
  gameId: 'myg',          // your game's canonical wire id: the registry key
  moveNamespace: 'myg',   // on-chain move namespace (Xaya `g/` key); usually the same, a deployment may override it
  title: 'My Game',       // display name in the shared shell screens
  storagePrefix: 'myg',   // prefix for every localStorage key this app owns
});
```

Every stored key the package owns, the judge loader's move namespace and the
shared screens' title read this back lazily through `appConfig()`. The read is
resolved at first *use*, not at import, so importing the package is always safe;
only rendering or using it before `configureApp` has run throws. Note that
`AppConfig.gameId` and `GameAdapter.gameId` are deliberately different values:
the first is the registry key, the second is the move namespace (see "The game
adapter").

An app that renders `Game` (the shell root) gets persisted-session restore for
free. An app that composes its own shell out of the standalone pieces
(`WalletLogin`, `ChannelLobby`, `ChannelGame`, `ModeSelect`) must call
`hydrateChannelStore()` itself, once, at start-up, before any of them render:
otherwise a returning player's saved name is never restored. It is safe to call
unconditionally: when embedded in the Arcade shell it no-ops the name restore,
because identity there comes from the shell, never from localStorage.

## Debug logging

The hot-path channel and relay logging: broadcast SEND/RECV, the per-move
sender dumps, relay lifecycle, and the channel manager: is **silent by
default**. Turn it on either way:

- **Build time:** set `NEXT_PUBLIC_DEBUG_CHANNEL=1`.
- **Runtime:** in the browser, `localStorage.setItem('<storagePrefix>_debug', '1')`
  then reload. `storagePrefix` is the value passed to `configureApp`: a game
  configured with `storagePrefix: 'xayaman'` uses the key `xayaman_debug`.

The gate itself is exported: `debugEnabled()` reads the flag (cached after the
first successful resolution), and `dlog(...)` / `dwarn(...)` are `console.log` /
`console.warn` that fire only when it is on (`src/lib/debug.ts`). Genuine
failures still use `console.error`/`console.warn` directly and always surface.

## The game adapter

Everything the generic channel UI needs to run one game funnels through a single
`GameAdapter` (`src/lib/games/adapter.ts`). The registry maps a game id to one
adapter, and no other frontend file names a specific game: adding a game is
adding an adapter module and registering it.

Registration is the other half of bootstrap, alongside `configureApp`, and must
run before anything renders:

```ts
import { registerAdapter } from '@xayaarcade/sdk';

registerAdapter('myg', myAdapter);   // keyed by the CANONICAL wire id: the same value passed as configureApp's `gameId`
```

An app hosts exactly one game, so `resolveGameId()` returns that single key and
treats zero or two registrations as a build error rather than guessing. Skipping
this half is not a quiet degradation: `resolveGameId()` is on the hot path for
the judge loader, the lobby and the live game screen, and an empty registry
throws there on first blob load.

| Field | Contract |
|---|---|
| `gameId: string` | The on-chain move namespace (the Xaya `g/` key). Env-overridable per deployment, and *not* the registry key. |
| `timing: GameTiming` | `'realtime'` or `'turnbased'`. Real-time games run an always-submit pump; turn-based games submit only on discrete actions. Gates the shell's real-time-only `net:` readout. |
| `ensureLoaded(): Promise<void>` | Ensure the game's judge module is loaded. Idempotent: safe to call repeatedly. |
| `makeBoardRules(): BoardRules` | Build a fresh `BoardRules` for a channel. |
| `makeOpenChannel(playerName): ArcadeChannel` | Build a fresh channel handle for a player. |
| `Renderer: ComponentType<GameRenderProps>` | The board renderer. It receives `{ localPlayerIndex }`. |
| `useInput(submit): void` | The input hook: wires up listeners and submits moves. `submit` is `null` until the channel is ready, so the hook must guard on it, and `submit` itself resolves `false` rather than throwing if the channel has since stopped being ready. The input value is opaque to the generic layer. |
| `controlsHint: ControlsHint` | The one-line controls help, shown in the menu and on the board: on a phone it is drawn across the frame just above the on-screen pad. A **string** is shown on every device, so write it for both audiences: name the keys, but keep whatever a player still needs when the keys are irrelevant (the win condition, the round format) in the same line. A **`{ keyboard, touch }` pair** lets the device choose: `touch` wherever the primary pointer is a touch screen (the same gate that mounts the pad), `keyboard` everywhere else: use it rather than printing "WASD move, Space bomb" directly above a d-pad. Keep both short: the narrowest screen the arcade supports is 320 px, where about 46 characters fit one line, and a wrapped second row eats into the board. |
| `stallGraceMs: number` | How long to wait before offering the "opponent stalled → File Dispute" affordance. |
| `presentation?: GamePresentation` | Optional. Absent means the shell simply fills the frame it is given. Its `fullFrameOnTouch` opts a tap-native game out of the letterbox on phones: see the presentation contract. |
| `touchControls?: TouchControlsSpec` | Optional. On-screen controls for coarse-pointer (touch) devices: a 4-way `dpad` (values are `KeyboardEvent.key` strings) and/or action `buttons` (`{ key, label }`). The SDK mounts the overlay automatically and synthesizes window KeyboardEvents for the declared keys, so the game's keyboard input hook needs no change. Absent means no on-screen controls (e.g. tap-native games); an empty spec is treated as absent. |

Two supporting shapes complete the surface. `ArcadeChannel extends OpenChannel`
(whose whole surface is `maybeAutoMove` as of 0.7.0) and adds the two setters the
channel manager drives (`setPlayerIndex(idx)` and `setPendingInput(input)`) so
the adapter's channel and its `useInput` are the only code that understands the
concrete input shape. `SubmitInput` is
`(input: unknown) => Promise<boolean>`: one unit of player input, resolving
`false` when the channel is not ready.

## Components and hooks a game touches

The package exports a lot; a game only interacts with a handful directly. The
rest (channel primitives, proto bindings, crypto, chain wiring, relay) is
plumbing the components below drive for you.

- **`Game`**: the shell root. Runs the whole flow: menu → channel login →
  lobby → live game. Restores a resumable channel on load and skips-and-clears
  a stale marker for a channel the player has left.
- **`ChannelLobby`**: the lobby. Create, join, abort, declare-loss and dispute
  channels on-chain; reads the open channels off the relay-pushed GSP state
  (polling the GSP directly only while the relay is down), filters the list
  down to this game's type and splits it into joinable and active by whether
  each channel's declared seat count is filled; offers the seat-count choice when
  creating; and renders the wager panel when wagering is configured.
- **`ChannelGame`**: the live channel. Drives play through
  `useChannelManager` + `useGspPolling`, renders the adapter's board, and on
  close derives and shows the outcome recap (`deriveMatchOutcome`), the dispute
  status, and any wager-close annotations.
- **`useChannelStore`**: the zustand store holding channel UI state. Its
  localStorage recovery is keyed by `appConfig().storagePrefix`, so two games on
  one origin stay apart. `hydrateChannelStore()` restores a saved session and
  no-ops the name restore when embedded (see "Configure before you render").
- **`useCoarsePointer()`**: `true` when the device's primary pointer is a
  touch screen. Gate a game's own touch-only UI on this: a tap-to-confirm
  bar, a fatter hit box, rather than re-deriving it: the `matchMedia` read
  has to sit in an effect, never in render scope, or the React Compiler
  memoizes the impure read and freezes the answer at `false` (invisible to
  jsdom tests, visible only in the built bundle). It returns `false` on the
  server and on the first client render, flipping after mount.
- **`useGspBlock()`**: the chain tip (`height`, `blockHash`). It moved out of
  `useGspPolling()` in 0.15.1 so that only the component displaying the tip
  re-renders once per block; call it in that component, not at the top of a
  screen, or the saving is given straight back.
- **`ensureGameJudge(gameId)` / `getLoadedJudge(gameId)`**: the judge loader,
  below.

Also exported for a custom shell: `WalletLogin`, `ModeSelect`, `DisputeStatus`,
`ErrorBoundary` and `ToastProvider` / `useToast`.

**`TouchControls`** is deliberately *not* exported: it is auto-mounted. When a
game's adapter declares `touchControls`, `ChannelGame` renders the on-screen
pad/buttons overlay by itself on coarse-pointer devices while input is live,
moves the `controlsHint` line clear of the pad (showing its `touch` wording when
the adapter declares one), and the bridge keeps the game full-frame on
phones by skipping the `arcade:presentation` post. A builder only declares the
adapter field; there is nothing to import, render or style. (A game that wants
the full frame *without* a d-pad sets `presentation.fullFrameOnTouch` instead.)

Two providers are not optional. An app wraps its tree in **`RuntimeConfigGate`**
, and it must sit *outside* `WagmiProvider`, because `wagmiConfig` is built
lazily on its first real read and that read happens the moment `WagmiProvider`
mounts; gating anywhere further in lets every wagmi hook run before
`/arcade-config.json` has resolved. Inside it, mount **`ArcadeBridgeProvider`**:
it is the game side of the arcade bridge, inert when standalone, and when
embedded it records the shell's identity into the channel store, announces the
game, and owns the whole postMessage protocol below, including the move and
wager brokers, so a game never writes a `postMessage` call itself. Read the
session through **`useArcadeSession`** (`embedded`, `address`, `writer`, `caps`)
or **`useArcadeBridge`** (`ready`, `sendMove`, `sendWagerOp`, `matchmake`,
`chromeHidden`, `requestChrome`, `announcePresentation`).

## The wasm judge

A game's rules ship as a zero-import WebAssembly blob registered on-chain by its
sha256 hash. The client runs that exact blob so it agrees with the host GSP.

`ensureGameJudge(gameId)` reads the registry row from the GSP
(`getcurrentstate`) for the game's pinned sha256, fetches that blob body
(`GspClient.getBlob`), inflates it under an 8 MiB decompressed cap enforced per
chunk (an oversized body is rejected mid-stream, never fully buffered) then
verifies the *decompressed* bytes hash to the pinned sha256 **before**
instantiating, and hands the verified bytes to `PackedJudge.instantiate`. Every
failure: no registered row, a fetch error, an over-cap body, a hash mismatch:
throws; there is no silent fallback. The result is cached per game id, so a
second call makes no RPC calls at all, and concurrent calls for the same
not-yet-loaded game share one in-flight fetch. The registry lookup uses the
canonical wire key (`resolveGameId()`), not the deployment-overridable adapter
`gameId`.

`getLoadedJudge(gameId)` returns the already-loaded judge, throwing if
`ensureGameJudge` has not loaded it yet.

`PackedJudge` is the raw-WASM client driver for the packed `arcade_*` ABI: no
emscripten glue. It instantiates the blob with `WebAssembly.instantiate` (empty
import object), runs the reactor's `_initialize()`, and drives its handle-based
exports: `arcade_parse_state` returns a handle, the queries
(`arcade_is_valid`, `arcade_whose_turn`, `arcade_turn_count`,
`arcade_is_finished`, `arcade_winner`, and the optional `arcade_ejected_mask`)
take the handle, `arcade_release` frees it. A single `parse()` call combines the
structural decode *and* the adversarial-validity check (`arcade_is_valid`), so a
caller only ever sees a live handle or `null`: a state that decodes but is
invalid is released and rejected. Every `arcade_alloc` buffer is freed on every
path, and an allocation failure is a rejection (`null`), not a throw: the same
fail-closed contract as any other reject.

## The channel config

`arcade_initial_state` takes one opaque config value, and the host builds it
from **registry data alone** (`engine/gsp/logic.cpp`, `BuildCfg`): it never
parses a cfg and knows no game's layout:

| the game's registered `cfgSuffix` | the cfg the host hands the blob |
|---|---|
| empty | **empty**: zero bytes, and no seed prefix either |
| anything else | `LE32(seed) ++ cfgSuffix` |

`ChannelConfig.build(seed, cfgSuffix)` is that rule, and `initialState` takes
the value it returns rather than loose bytes, so a client cannot silently
disagree with the referee. The suffix is raw bytes or the hex the registry
stores; there is no default, so a game that takes no config says `''`.

```ts
const cfg = ChannelConfig.build(seed, '0102090c068403'); // 4 + 7 = 11 bytes
const state = judge.initialState(2, cfg);                // null if the blob refuses
```

Nothing about a cfg is universal: the five live games are registered with
suffixes of 0, 8, 7, 1 and 0 bytes, so their blobs demand cfgs of 0, 12, 11, 5
and 0 bytes, and a blob handed a shape it was not written for rejects it. That
rejection is silent where it hurts most: a channel that simply wedges
part-filled, which is why the type exists: a bare `Uint8Array` parameter lets
one game's cfg reach another game's blob unnoticed.

`seedFromChannelId(channelId)` reproduces the seed the host derives (the top 32
bits of the channel id), for a client that needs to rebuild an on-chain
channel's initial state itself. An offline harness picks its own seed.

## The presentation contract

A game can tell its host the shape it wants to be drawn at. The contract is
declared on the adapter as `GamePresentation` (`src/lib/games/adapter.ts`):

- `aspectRatio: number`: width / height of the play surface at its natural
  shape (`1` = square).
- `minViewport: { width, height }`: CSS px. Below this box the host should
  letterbox or scroll rather than squash the game.
- `immersive?: 'never' | 'preferred'`: whether the game may ask the host to
  hide its chrome. Defaults to `'never'`.
- `fullFrameOnTouch?: boolean`: take the whole frame on a coarse-pointer
  (touch) device rather than being letterboxed to `aspectRatio`. Defaults to
  `false`. For a tap-native game the board *is* the input surface, so a
  letterbox costs twice: dead gutter across half a phone screen, and smaller
  tap targets in what is left. A game that declares `touchControls` gets the
  same treatment implicitly (its on-screen pad has to live in the game's own
  gutter) and need not set this as well. A fine pointer is never affected.

Every field is advisory: a host may ignore all of it, and a game may omit the
whole object. When embedded, this same information travels to the shell over the
bridge as `arcade:presentation` (with `minViewport` flattened to `minWidth` /
`minHeight`): the adapter is the source, the message is the transport. The
full-frame cases are the exception that proves it: the bridge posts *no*
message at all, and "no presentation" is exactly the shell behaviour they want.

## Runtime config and the identity gate

An arcade-hosted bundle is built deployment-blind: no GSP, relay, chain-RPC or
arcade-origin URL is baked into the bundle. The serving layer publishes a
same-origin `/arcade-config.json` per game, and the SDK fetches it once at boot
(`loadArcadeRuntimeConfigOutcome()`, `cache: 'no-store'`). Every config getter consults
that store first and falls back to its env-derived value, so dev servers and
standalone builds keep working unchanged: a 404 or an invalid file resolves to
`null` and the SDK behaves as pure-env.

`ArcadeRuntimeConfig` (`src/lib/config/runtime-config.ts`):

| Field | Meaning |
|---|---|
| `gspUrl` | Host GSP base URL. Must match `^https?://`. |
| `relayUrl` | Relay WebSocket URL. Must match `^wss?://`. |
| `chainRpcUrl` | Polygon RPC URL. Must match `^https?://`. |
| `arcadeOrigin` | The shell origin allowed to embed and message this game. Non-empty. |
| `gameId` | The move namespace this deployment is registered under. Non-empty. |
| `devWallet` | Whether the operator has enabled the dev-wallet affordance. Boolean. |
| `wagerAddress?` | The ArcadeWager contract address, when wagering is enabled. Kept only when it validates as a non-zero `0x`-40-hex string; an invalid value is dropped and the rest of the config still loads. |
| `wagerBeta?` | Marks this plane a wagering beta. Kept only on a literal `true`; anything else is treated as absent. It is what enables the SDK's pre-stake payout disclosure, so a plane running real money in beta sets it and no other plane does. |
| `relayUrls?` | Every relay this plane runs, home relay first (`relayUrl` is its head). The frame times a probe to each and talks to the nearest. Kept only when every entry matches `^wss?://` and there are at most `MAX_RELAY_URLS` (8) of them; a list failing either test is dropped whole and the frame stays on `relayUrl` alone, so a serving layer should refuse such a list at startup rather than publish it. `isRelayUrl` and `MAX_RELAY_URLS` are exported (main entry and `/server`) so it can apply the same test. |

`arcadeRuntimeConfig()` is the synchronous read: `null` before the load
completes or when the game is not hosted.

**The identity gate.** `RuntimeConfigGate` blocks the app until the runtime
config resolves, so nothing consumes a config value before
`/arcade-config.json` has been fetched. It **fails closed** if the served
config's `gameId` does not equal `appConfig().moveNamespace`, rendering a
refusal screen (*"This deployment is configured for a different game) refusing
to start. (bundle/registration mismatch)"*, rather than running a bundle under
the wrong registration. It compares `moveNamespace`, not the adapter `gameId`,
because a deployment may run many games under one shared namespace and the namespace is
what the wire actually carries. On a dev server the fetch 404s instantly and
children render with pure-env config, so there is no behaviour change.

## Wagering

Wagering is enabled per game by operator registration data, never by the bundle.
`wagerAddress()` (`src/lib/wager/wager-config.ts`) is read at call time: the
served runtime config's `wagerAddress` wins first, then `NEXT_PUBLIC_WAGER_ADDRESS`
as an env fallback for a dev server or standalone build: the same
"operator wins, env is the fallback" rule the bridge config uses. The candidate
is validated and normalized (a `0x`-40-hex address, lowercased, zero address
rejected). `wagerConfigured()` is simply `wagerAddress() !== null`.

When no wager address is configured anywhere, wagering is fully inert and **free
play renders byte-identically either way**: this is a stated invariant of the
module, not an incidental outcome. The standalone wager reads, writes and error
copy are exported for a game that builds its own wager UI; the shell bridge never
touches them, because a brokered embed only ever carries plain XayaAccounts
moves.

## The arcade bridge protocol

When a game runs embedded inside the Arcade shell it holds no wallet. The shell
owns the wallet, the player's name and all on-chain signing; the game asks the
shell to sign, over a `postMessage` protocol whose message shape *is* the
contract. The same shape is duplicated verbatim in the shell repo
([`xaya-arcade`](https://github.com/xaya/xaya-arcade)) at
`src/lib/arcade-bridge/protocol.ts`: the two repos ship separately and cannot
share a module, so the wire is the agreement. This side's definitions live in
`src/lib/arcade-bridge/protocol.ts` too. A game
builder does not implement any of it by hand: `ArcadeBridgeProvider` speaks it
on the game's behalf. What follows is the contract, not a to-do list.

The contract is **additive-only**: the original eight messages stay
byte-identical forever, and new message types are only ever appended (the
wager/caps trio and `arcade:matchmake` are such additions). An unknown `type` makes `parseArcadeMessage`
return `null`, and both routers drop a `null` parse in silence: nothing crashes,
nothing logs, so a game speaking a newer message at an older peer, or the
reverse, is a harmless no-op.

### Messages

| Type | Direction | Payload |
|---|---|---|
| `arcade:hello` | game → shell | `{}`. The game announcing itself. |
| `arcade:identity` | shell → game | `{ address, xayaName }`. The connected wallet address (`0x`-40-hex) or `null`, and the Xaya name or `null` when disconnected. |
| `arcade:move-request` | game → shell | `{ id, moveJson, signerName }`. A move the game wants signed, bound to the participant it signs as. |
| `arcade:move-result` | shell → game | `{ id, txHash, error }`. The outcome: at least one of `txHash` or `error` must be non-null; a result carrying neither is rejected. |
| `arcade:presentation` | game → shell | `{ aspectRatio, minWidth, minHeight, immersive }`. The shape the game wants (see the presentation contract). |
| `arcade:chrome` | game → shell | `{ hidden }`. A *request* to hide or restore the shell chrome, not a fact. |
| `arcade:chrome-state` | shell → game | `{ hidden }`. The chrome state as it now *is*. The only source of truth. |
| `arcade:theme` | shell → game | `{ tokens }`. Sanitized CSS custom properties to paint with (never inherited across the iframe boundary, so they can only arrive over the wire). |
| `arcade:wager-request` | game → shell | `{ id, op, bet?, numPlayers?, matchIdx?, signingAddr? }`. One ArcadeWager operation to run. |
| `arcade:wager-result` | shell → game | `{ id, txHash, error }`. The wager op's outcome: same rule as `arcade:move-result`: a result carrying neither a tx hash nor an error is rejected. |
| `arcade:caps` | shell → game | `{ wager }`. Which optional capabilities the shell offers this game. `wager` false, or never sent, means the game shows no wager UI: the free-play default. |
| `arcade:matchmake` | shell → game | `{ role, seats, tier, peerName, ts }`. A cross-game-lobby handoff: the two players already agreed in the arcade's lobby, so the game pre-fills and **arms** its own create/join UI. It never auto-signs. `role` is `'create'` or `'join'`, `tier` is `'free'` or a strict decimal WCHI base-unit string, `peerName` is namespace-stripped. |

**Move requests.** `signerName` is REQUIRED as of 0.8.0. It names the game's
own channel participant, so the shell refuses to sign under a different name if
the player switched arcade identity mid-channel. A game can only ever bind its
*own* participant name, so this never widens what it can sign. A request
without it is refused: the shell answers an error `move-result` (so the game
errors instead of hanging), and the SDK's own `MoveBroker`/`BrokeredWriter`
throw before posting at all.

**Theme tokens** are the shell's alone to define, but the parser enforces the
allow-list either side would need anyway: keys must match
`--arcade-[a-z0-9-]{1,60}`, values must be a hex colour (`#` + 3–8 hex), an
`rgb`/`rgba`/`hsl`/`hsla` function, or a narrow word / font-stack form, with no
parens outside the colour functions and none of `;`/`{`/`}`/`:` that could close
one declaration and open another. A message carrying more than 64 tokens
(`MAX_THEME_TOKENS`) is rejected whole: `parseArcadeMessage` returns `null` and
nothing is applied, rather than the first 64 being kept. Within that cap, each
individual key or value that fails the allow-list is dropped and the surviving
tokens still apply; a message whose every token is rejected is still
well-formed, the game just paints nothing new.

### Wager operations

`WAGER_OPS`, in contract order, is the exact set the shell validates a request
against before it will sign anything:

`approve`, `createMatch`, `joinMatch`, `leaveMatch`, `abortMatch`,
`expireMatch`, `refreshQueue`.

Each op declares exactly which fields it uses; the parser rebuilds the message
from only those fields, so an unknown key (or a known key belonging to a
different op, or a wallet address the game must never send) is silently dropped:

| Op | Required fields |
|---|---|
| `approve` | none |
| `createMatch` | `bet` (strict-decimal WCHI base units), `numPlayers` (integer 2–8), `signingAddr` |
| `joinMatch` | `matchIdx` (strict decimal), `signingAddr` |
| `leaveMatch` / `abortMatch` / `expireMatch` / `refreshQueue` | `matchIdx` (strict decimal) |

`bet` and `matchIdx` are strict decimal strings (`^(0|[1-9][0-9]*)$`: no
leading zeros, sign or fraction). `numPlayers` is an integer seat count in the
range 2–8.

### Security posture

Both sides receive arbitrary cross-origin window messages, so the protocol is
built to trust nothing about their shape:

- **`parseArcadeMessage` is the single trust gate.** It validates every field
  and returns `null` on anything malformed: it never throws and never trusts a
  shape it did not verify. `originAllowed(origin, allowed)` is the companion
  origin check: an exact-match gate that fails closed on an empty allowlist and
  never substring-matches.
- **The shell is the only signer, and it signs narrowly.** On a move request the
  shell signs *only* `XayaAccounts.move` for its own name with zero value, so a
  hostile game frame cannot widen a request into an arbitrary transaction. Every
  brokered payload is a single-game envelope.
- **Game frames never supply money parameters.** A wager request never carries a
  wallet address or a game type; the shell injects those from its own trusted
  identity when it signs the ArcadeWager call. The `signingAddr` a game sends is
  *not* a wallet address: it is the channel signing/session address the game
  generates, and it is validated by `isSigningAddrSafe`: non-empty printable
  ASCII excluding the double-quote (`0x22`) and backslash (`0x5c`) that would
  break the JSON move the GSP must parse, mirroring
  `ArcadeWager._isSigningAddrSafe` on-chain.

## `@xayaarcade/sdk/e2e`: the node-only harness surface

A game repo's own scenario runner builds on this subpath: it reaches
`ChannelManager`, `MoveSender`, the state-proof/signature primitives, the
`PackedJudge`, `ChannelConfig`, the on-chain move builders and `OnChainMoves`,
without touching the browser entry (which pulls the wagmi/connectkit stack a
`tsx`/`node` script cannot resolve). Two stand-ins let a scenario run with no
external services at all:

- **`InMemoryBus` + `DirectBroadcast`**: the relay leg, in-process. For the
  real thing, `WsBroadcast` is exported here too and speaks the wire protocol a
  live game speaks.
- **`RecordingTxSender`**: the chain leg. A `TransactionSender` that RECORDS
  every attempt instead of sending it, so a scenario expecting a dispute to
  reach chain can assert on `sent` (or `withKey('d')`) rather than merely not
  crashing. `{ autoMine: false }` holds everything unconfirmed until
  `mine()`/`mineAll()`, for testing a client while a tx is in flight.

### The Node `localStorage` trap

A client that keeps per-seat secrets in `localStorage` (a hidden-information
game's seed, its commitment openings, a session key) breaks under Node, and the
**guarded** case is the dangerous one. Bare Node has no `localStorage`
(`typeof localStorage === 'undefined'`), so an unguarded write throws a
`ReferenceError` straight away: loud, and easy to chase. But browser-targeting
code routinely guards the access, and under Node that guard is simply false:
the write is skipped, nothing throws, and the seat then commits rounds it can
never open. It surfaces much later as a mysterious forfeit, never as a storage
error. Run each seat process with

```
node --experimental-webstorage --localstorage-file=<one path per seat>
```

The per-process file is not bookkeeping: it is what gives the seats real
isolation, so no seat can read another's secrets, which a single-process
harness sharing one `localStorage` silently does not have. This is repeated in
the `sdk/src/e2e/index.ts` module doc comment, where a consumer reading the
entry point will meet it.
